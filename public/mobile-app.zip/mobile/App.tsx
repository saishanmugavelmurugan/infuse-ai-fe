/**
 * HealthTrack Pro Mobile App
 * Cross-platform health tracking application
 * 
 * Features:
 * - Native health data sync (Apple HealthKit / Android Health Connect)
 * - Patient dashboard with health metrics
 * - Doctor directory with search and filters
 * - Appointment booking and management
 * - AI-powered wellness plans
 * - User profile and settings
 */

import React from 'react';
import { StatusBar, Platform } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Icon from 'react-native-vector-icons/Feather';

// Screens
import HealthDashboard from './src/screens/HealthDashboard';
import DoctorsScreen from './src/screens/DoctorsScreen';
import AppointmentsScreen from './src/screens/AppointmentsScreen';
import WellnessScreen from './src/screens/WellnessScreen';
import ProfileScreen from './src/screens/ProfileScreen';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

// Tab Navigator
const TabNavigator = () => {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName: string;
          
          switch (route.name) {
            case 'Health':
              iconName = 'activity';
              break;
            case 'Doctors':
              iconName = 'users';
              break;
            case 'Appointments':
              iconName = 'calendar';
              break;
            case 'Wellness':
              iconName = 'heart';
              break;
            case 'Profile':
              iconName = 'user';
              break;
            default:
              iconName = 'circle';
          }
          
          return <Icon name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: '#FF6B35',
        tabBarInactiveTintColor: '#999',
        tabBarStyle: {
          backgroundColor: '#FFF',
          borderTopWidth: 0,
          elevation: 10,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: -2 },
          shadowOpacity: 0.1,
          shadowRadius: 8,
          height: Platform.OS === 'ios' ? 85 : 65,
          paddingBottom: Platform.OS === 'ios' ? 25 : 10,
          paddingTop: 10,
        },
        tabBarLabelStyle: {
          fontSize: 11,
          fontWeight: '500',
        },
        headerShown: false,
      })}
    >
      <Tab.Screen 
        name="Health" 
        component={HealthDashboard}
        options={{ tabBarLabel: 'Health' }}
      />
      <Tab.Screen 
        name="Doctors" 
        component={DoctorsScreen}
        options={{ tabBarLabel: 'Doctors' }}
      />
      <Tab.Screen 
        name="Appointments" 
        component={AppointmentsScreen}
        options={{ tabBarLabel: 'Appointments' }}
      />
      <Tab.Screen 
        name="Wellness" 
        component={WellnessScreen}
        options={{ tabBarLabel: 'Wellness' }}
      />
      <Tab.Screen 
        name="Profile" 
        component={ProfileScreen}
        options={{ tabBarLabel: 'Profile' }}
      />
    </Tab.Navigator>
  );
};

// Main App
const App = () => {
  return (
    <NavigationContainer>
      <StatusBar 
        barStyle="dark-content" 
        backgroundColor="#FFF" 
      />
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Main" component={TabNavigator} />
        {/* Add more screens for modals/detail views */}
        {/*
        <Stack.Screen name="DoctorDetail" component={DoctorDetailScreen} />
        <Stack.Screen name="BookAppointment" component={BookAppointmentScreen} />
        <Stack.Screen name="AppointmentDetail" component={AppointmentDetailScreen} />
        <Stack.Screen name="Login" component={LoginScreen} />
        */}
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default App;
