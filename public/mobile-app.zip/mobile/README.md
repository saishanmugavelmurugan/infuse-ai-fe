# HealthTrack Pro Mobile App

Cross-platform mobile application for HealthTrack Pro, built with React Native.

## Features

- **Native Health Data Sync**
  - 🍎 **iOS**: Apple HealthKit integration
  - 🤖 **Android**: Health Connect integration (modern standard)
- **Patient Dashboard**: View real-time health metrics
- **Doctor Directory**: Browse and search doctors
- **Appointment Booking**: Schedule consultations
- **AI Wellness Plans**: Personalized health recommendations

## Health Data Supported

| Metric | iOS (HealthKit) | Android (Health Connect) |
|--------|-----------------|--------------------------|
| Steps | ✅ | ✅ |
| Heart Rate | ✅ | ✅ |
| Sleep Analysis | ✅ | ✅ |
| Distance | ✅ | ✅ |
| Calories | ✅ | ✅ |
| Floors Climbed | ✅ | ✅ |
| Blood Pressure | ✅ | ✅ |
| Blood Glucose | ✅ | ✅ |
| Oxygen Saturation | ✅ | ✅ |
| Weight/BMI | ✅ | ✅ |

## Prerequisites

### General
- Node.js >= 18
- Yarn or npm
- React Native CLI

### iOS
- macOS with Xcode 15+
- CocoaPods
- Apple Developer Account (for HealthKit)

### Android
- Android Studio
- JDK 17+
- Health Connect app installed on device/emulator

## Installation

```bash
# Clone and navigate to mobile directory
cd /app/mobile

# Install dependencies
yarn install

# iOS: Install pods
cd ios && pod install && cd ..

# Start Metro bundler
yarn start
```

## Running the App

### iOS Simulator
```bash
yarn ios
```

### Android Emulator
```bash
yarn android
```

## iOS Setup - Apple HealthKit

### 1. Enable HealthKit Capability
In Xcode:
1. Open `ios/HealthTrackPro.xcworkspace`
2. Select the project target
3. Go to "Signing & Capabilities"
4. Click "+ Capability"
5. Add "HealthKit"

### 2. Configure Info.plist
The following permissions are already configured in `ios/HealthTrackPro/Info.plist`:

```xml
<key>NSHealthShareUsageDescription</key>
<string>HealthTrack Pro needs to read your health data...</string>

<key>NSHealthUpdateUsageDescription</key>
<string>HealthTrack Pro can record your workouts...</string>
```

### 3. Background Delivery (Optional)
For real-time updates while app is in background:
1. Enable "Background Modes" capability
2. Check "Background fetch"
3. Check "Background processing"

## Android Setup - Health Connect

### 1. Install Health Connect
Health Connect must be installed on the device:
- [Play Store Link](https://play.google.com/store/apps/details?id=com.google.android.apps.healthdata)

### 2. Permissions Declaration
The following permissions are already configured in `AndroidManifest.xml`:

```xml
<!-- Read Permissions -->
<uses-permission android:name="android.permission.health.READ_STEPS" />
<uses-permission android:name="android.permission.health.READ_HEART_RATE" />
<uses-permission android:name="android.permission.health.READ_SLEEP" />
<!-- ... more permissions ... -->
```

### 3. Privacy Policy Activity
A `PermissionsRationaleActivity` is required for Health Connect:
```xml
<activity android:name=".PermissionsRationaleActivity" android:exported="true">
    <intent-filter>
        <action android:name="androidx.health.ACTION_SHOW_PERMISSIONS_RATIONALE" />
    </intent-filter>
</activity>
```

## Architecture

```
/app/mobile/
├── ios/
│   └── HealthTrackPro/
│       ├── Info.plist           # HealthKit permissions
│       └── *.entitlements       # HealthKit capability
├── android/
│   └── app/src/main/
│       └── AndroidManifest.xml  # Health Connect permissions
├── src/
│   ├── services/
│   │   ├── HealthService.ts     # Unified cross-platform API
│   │   ├── AppleHealthKit.ts    # iOS-specific implementation
│   │   └── HealthConnect.ts     # Android-specific implementation
│   ├── screens/
│   │   └── HealthDashboard.tsx  # Main health data display
│   ├── components/
│   ├── hooks/
│   ├── utils/
│   └── navigation/
├── App.tsx                      # App entry point
└── package.json
```

## Usage

### Initialize Health Service
```typescript
import healthService from './services/HealthService';

// Check availability
const available = await healthService.isAvailable();

// Initialize and request permissions
const success = await healthService.initialize();

// Get today's activity
const metrics = await healthService.getTodayActivity();
console.log(`Steps: ${metrics.steps}`);

// Get heart rate
const heartRate = await healthService.getHeartRate();
console.log(`Current BPM: ${heartRate.current}`);

// Get sleep data
const sleep = await healthService.getSleepAnalysis();
console.log(`Sleep: ${sleep.totalMinutes} minutes`);
```

### Sync All Data
```typescript
const result = await healthService.syncAllData();

if (result.success) {
  console.log('Steps:', result.metrics.steps);
  console.log('Heart Rate:', result.heartRate.current);
  console.log('Sleep:', result.sleep.totalMinutes);
}
```

## No OAuth Required

This implementation uses **native on-device permissions**:

- **iOS**: HealthKit permissions are requested via the native iOS dialog
- **Android**: Health Connect permissions are requested via the Health Connect app

Users do NOT need to log into any external website or OAuth flow.

## Testing

### iOS
1. Use a real iPhone device (HealthKit is limited in simulator)
2. Ensure Health app has some data
3. Grant permissions when prompted

### Android
1. Install Health Connect from Play Store
2. Ensure Health Connect has some data (from other fitness apps)
3. Grant permissions when prompted

## Troubleshooting

### iOS: "HealthKit not available"
- HealthKit requires a real device, not simulator
- Ensure HealthKit capability is enabled in Xcode

### Android: "Health Connect not installed"
- Install Health Connect from Play Store
- For emulator, use API 34+ with Play Store support

### No data showing
- Ensure health apps have recorded data
- Check that permissions were granted
- Pull to refresh the dashboard

## Security & Privacy

- Health data is processed **on-device only**
- No health data is sent to external servers without explicit user consent
- All API communications use HTTPS
- Data is stored securely using platform keychain/keystore

## License

Proprietary - Infuse Healthcare Solutions
