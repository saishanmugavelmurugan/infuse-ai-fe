/**
 * App Configuration
 * Centralized configuration for API endpoints and app settings
 */

// API Base URL - Update this for production
export const API_BASE_URL = __DEV__
  ? 'http://localhost:8001'  // Development
  : 'https://infuse.net.in'; // Production

// App Configuration
export const APP_CONFIG = {
  name: 'HealthTrack Pro',
  version: '1.0.0',
  buildNumber: '1',
  
  // Feature flags
  features: {
    healthKit: true,
    healthConnect: true,
    offlineMode: true,
    pushNotifications: true,
    videoConsulting: true,
  },
  
  // API Endpoints
  endpoints: {
    auth: {
      login: '/api/auth/login',
      register: '/api/auth/register',
      me: '/api/auth/me',
      logout: '/api/auth/logout',
    },
    doctors: {
      list: '/api/doctors/',
      detail: '/api/doctors/:id',
      specialties: '/api/doctors/specialties',
    },
    appointments: {
      list: '/api/healthtrack/appointments',
      create: '/api/healthtrack/appointments',
      cancel: '/api/healthtrack/appointments/:id/cancel',
      slots: '/api/healthtrack/appointments/slots/available',
    },
    wellness: {
      generatePlan: '/api/ai-wellness/generate-plan',
      savedPlans: '/api/ai-wellness/plans',
    },
    health: {
      sync: '/api/health-sync/data',
      platforms: '/api/health-sync/platforms',
    },
  },
  
  // Storage keys
  storageKeys: {
    authToken: 'auth_token',
    userData: 'user_data',
    cachedDoctors: 'cached_doctors',
    cachedAppointments: 'cached_appointments',
    cachedWellnessPlan: 'cached_wellness_plan',
    healthData: 'cached_health_data',
    settings: 'app_settings',
  },
  
  // Timeouts
  timeouts: {
    api: 30000, // 30 seconds
    healthSync: 60000, // 60 seconds
  },
};

export default APP_CONFIG;
