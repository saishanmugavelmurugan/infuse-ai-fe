/**
 * Unified Health Service
 * Cross-platform health data abstraction
 * 
 * Automatically uses:
 * - Apple HealthKit on iOS
 * - Health Connect on Android
 * 
 * No OAuth required - uses native on-device permissions
 */

import { Platform } from 'react-native';
import appleHealthKitService, {
  HealthMetrics,
  HeartRateData,
  SleepData,
  VitalsData,
  BodyMeasurements,
} from './AppleHealthKit';
import healthConnectService from './HealthConnect';

export type { HealthMetrics, HeartRateData, SleepData, VitalsData, BodyMeasurements };

export interface HealthServiceStatus {
  available: boolean;
  initialized: boolean;
  permissionsGranted: boolean;
  platform: 'ios' | 'android';
  serviceName: string;
  error?: string;
}

export interface HealthSyncResult {
  success: boolean;
  lastSynced: Date;
  metrics: HealthMetrics;
  heartRate: HeartRateData;
  sleep: SleepData;
  vitals: VitalsData;
  bodyMeasurements: BodyMeasurements;
}

class UnifiedHealthService {
  private isInitialized: boolean = false;
  private permissionsGranted: boolean = false;
  private lastSyncTime: Date | null = null;

  /**
   * Get the current platform
   */
  get platform(): 'ios' | 'android' {
    return Platform.OS as 'ios' | 'android';
  }

  /**
   * Get the platform-specific service name
   */
  get serviceName(): string {
    return this.platform === 'ios' ? 'Apple HealthKit' : 'Health Connect';
  }

  /**
   * Check if health services are available on this device
   */
  async isAvailable(): Promise<boolean> {
    try {
      if (this.platform === 'ios') {
        return await appleHealthKitService.isAvailable();
      } else {
        const availability = await healthConnectService.checkAvailability();
        return availability.available;
      }
    } catch (error) {
      console.error('[HealthService] Availability check error:', error);
      return false;
    }
  }

  /**
   * Get detailed status of health services
   */
  async getStatus(): Promise<HealthServiceStatus> {
    const available = await this.isAvailable();
    
    return {
      available,
      initialized: this.isInitialized,
      permissionsGranted: this.permissionsGranted,
      platform: this.platform,
      serviceName: this.serviceName,
    };
  }

  /**
   * Initialize health service and request permissions
   */
  async initialize(): Promise<boolean> {
    try {
      console.log(`[HealthService] Initializing ${this.serviceName}...`);
      
      if (this.platform === 'ios') {
        const success = await appleHealthKitService.initialize();
        this.isInitialized = success;
        this.permissionsGranted = success;
        return success;
      } else {
        // Android - Initialize and request permissions separately
        const initSuccess = await healthConnectService.initialize();
        if (!initSuccess) {
          return false;
        }
        
        const permSuccess = await healthConnectService.requestPermissions();
        this.isInitialized = initSuccess;
        this.permissionsGranted = permSuccess;
        return initSuccess && permSuccess;
      }
    } catch (error) {
      console.error('[HealthService] Initialization error:', error);
      return false;
    }
  }

  /**
   * Request health data permissions (Android only - iOS requests during init)
   */
  async requestPermissions(): Promise<boolean> {
    if (this.platform === 'ios') {
      // iOS permissions are requested during initialization
      return this.permissionsGranted;
    } else {
      const granted = await healthConnectService.requestPermissions();
      this.permissionsGranted = granted;
      return granted;
    }
  }

  /**
   * Get today's activity metrics (steps, distance, calories, etc.)
   */
  async getTodayActivity(): Promise<HealthMetrics> {
    if (!this.isInitialized) {
      console.warn('[HealthService] Not initialized');
      return this.getEmptyMetrics();
    }

    try {
      if (this.platform === 'ios') {
        return await appleHealthKitService.getTodayActivity();
      } else {
        return await healthConnectService.getTodayActivity();
      }
    } catch (error) {
      console.error('[HealthService] Activity read error:', error);
      return this.getEmptyMetrics();
    }
  }

  /**
   * Get heart rate data
   */
  async getHeartRate(startDate?: Date): Promise<HeartRateData> {
    if (!this.isInitialized) {
      return this.getEmptyHeartRate();
    }

    try {
      if (this.platform === 'ios') {
        return await appleHealthKitService.getHeartRate(startDate);
      } else {
        return await healthConnectService.getHeartRate(startDate);
      }
    } catch (error) {
      console.error('[HealthService] Heart rate read error:', error);
      return this.getEmptyHeartRate();
    }
  }

  /**
   * Get sleep analysis data
   */
  async getSleepAnalysis(startDate?: Date): Promise<SleepData> {
    if (!this.isInitialized) {
      return this.getEmptySleep();
    }

    try {
      if (this.platform === 'ios') {
        return await appleHealthKitService.getSleepAnalysis(startDate);
      } else {
        return await healthConnectService.getSleepAnalysis(startDate);
      }
    } catch (error) {
      console.error('[HealthService] Sleep read error:', error);
      return this.getEmptySleep();
    }
  }

  /**
   * Get body measurements (weight, height, BMI, body fat)
   */
  async getBodyMeasurements(): Promise<BodyMeasurements> {
    if (!this.isInitialized) {
      return this.getEmptyBodyMeasurements();
    }

    try {
      if (this.platform === 'ios') {
        return await appleHealthKitService.getBodyMeasurements();
      } else {
        return await healthConnectService.getBodyMeasurements();
      }
    } catch (error) {
      console.error('[HealthService] Body measurements read error:', error);
      return this.getEmptyBodyMeasurements();
    }
  }

  /**
   * Get vitals data (blood pressure, glucose, oxygen, etc.)
   */
  async getVitals(): Promise<VitalsData> {
    if (!this.isInitialized) {
      return this.getEmptyVitals();
    }

    try {
      if (this.platform === 'ios') {
        return await appleHealthKitService.getVitals();
      } else {
        return await healthConnectService.getVitals();
      }
    } catch (error) {
      console.error('[HealthService] Vitals read error:', error);
      return this.getEmptyVitals();
    }
  }

  /**
   * Get historical steps data for charts
   */
  async getHistoricalSteps(days: number = 7): Promise<Array<{ date: string; value: number }>> {
    if (!this.isInitialized) {
      return [];
    }

    try {
      if (this.platform === 'ios') {
        return await appleHealthKitService.getHistoricalSteps(days);
      } else {
        return await healthConnectService.getHistoricalSteps(days);
      }
    } catch (error) {
      console.error('[HealthService] Historical steps error:', error);
      return [];
    }
  }

  /**
   * Sync all health data at once
   */
  async syncAllData(): Promise<HealthSyncResult> {
    if (!this.isInitialized) {
      return {
        success: false,
        lastSynced: new Date(),
        metrics: this.getEmptyMetrics(),
        heartRate: this.getEmptyHeartRate(),
        sleep: this.getEmptySleep(),
        vitals: this.getEmptyVitals(),
        bodyMeasurements: this.getEmptyBodyMeasurements(),
      };
    }

    try {
      const [metrics, heartRate, sleep, vitals, bodyMeasurements] = await Promise.all([
        this.getTodayActivity(),
        this.getHeartRate(),
        this.getSleepAnalysis(),
        this.getVitals(),
        this.getBodyMeasurements(),
      ]);

      this.lastSyncTime = new Date();

      return {
        success: true,
        lastSynced: this.lastSyncTime,
        metrics,
        heartRate,
        sleep,
        vitals,
        bodyMeasurements,
      };
    } catch (error) {
      console.error('[HealthService] Sync error:', error);
      return {
        success: false,
        lastSynced: new Date(),
        metrics: this.getEmptyMetrics(),
        heartRate: this.getEmptyHeartRate(),
        sleep: this.getEmptySleep(),
        vitals: this.getEmptyVitals(),
        bodyMeasurements: this.getEmptyBodyMeasurements(),
      };
    }
  }

  /**
   * Save a workout (write to health platform)
   */
  async saveWorkout(
    type: string,
    startDate: Date,
    endDate: Date,
    calories: number,
    distance?: number
  ): Promise<boolean> {
    if (!this.isInitialized) {
      return false;
    }

    try {
      if (this.platform === 'ios') {
        return await appleHealthKitService.saveWorkout(type, startDate, endDate, calories, distance);
      } else {
        // Health Connect write would be implemented similarly
        console.log('[HealthService] Workout save for Android not yet implemented');
        return false;
      }
    } catch (error) {
      console.error('[HealthService] Workout save error:', error);
      return false;
    }
  }

  /**
   * Get last sync time
   */
  getLastSyncTime(): Date | null {
    return this.lastSyncTime;
  }

  // Empty data helpers
  private getEmptyMetrics(): HealthMetrics {
    return {
      steps: 0,
      distance: 0,
      activeCalories: 0,
      totalCalories: 0,
      flightsClimbed: 0,
      exerciseMinutes: 0,
    };
  }

  private getEmptyHeartRate(): HeartRateData {
    return {
      current: 0,
      resting: 0,
      average: 0,
      min: 0,
      max: 0,
      samples: [],
    };
  }

  private getEmptySleep(): SleepData {
    return {
      totalMinutes: 0,
      inBedMinutes: 0,
      awakeMinutes: 0,
      remMinutes: 0,
      deepMinutes: 0,
      lightMinutes: 0,
      sleepScore: 0,
      sessions: [],
    };
  }

  private getEmptyVitals(): VitalsData {
    return {
      bloodPressure: null,
      bloodGlucose: null,
      oxygenSaturation: null,
      respiratoryRate: null,
      bodyTemperature: null,
    };
  }

  private getEmptyBodyMeasurements(): BodyMeasurements {
    return {
      weight: null,
      height: null,
      bmi: null,
      bodyFatPercentage: null,
    };
  }

  /**
   * Cleanup and release resources
   */
  cleanup(): void {
    if (this.platform === 'ios') {
      appleHealthKitService.cleanup();
    }
    this.isInitialized = false;
    this.permissionsGranted = false;
  }
}

// Export singleton instance
export const healthService = new UnifiedHealthService();
export default healthService;
