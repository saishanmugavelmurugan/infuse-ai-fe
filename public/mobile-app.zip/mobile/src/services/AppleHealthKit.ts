/**
 * Apple HealthKit Service
 * Native iOS health data integration
 * 
 * Handles: Steps, Heart Rate, Sleep, Activity, Weight, Blood Pressure, etc.
 */

import AppleHealthKit, {
  HealthKitPermissions,
  HealthInputOptions,
  HealthValue,
  HealthObserver,
} from 'react-native-health';

// Health data types we want to read/write
const HEALTHKIT_PERMISSIONS: HealthKitPermissions = {
  permissions: {
    read: [
      // Activity
      AppleHealthKit.Constants.Permissions.Steps,
      AppleHealthKit.Constants.Permissions.StepCount,
      AppleHealthKit.Constants.Permissions.DistanceWalkingRunning,
      AppleHealthKit.Constants.Permissions.FlightsClimbed,
      AppleHealthKit.Constants.Permissions.ActiveEnergyBurned,
      AppleHealthKit.Constants.Permissions.BasalEnergyBurned,
      AppleHealthKit.Constants.Permissions.AppleExerciseTime,
      AppleHealthKit.Constants.Permissions.AppleStandTime,
      AppleHealthKit.Constants.Permissions.Workout,
      
      // Heart & Vitals
      AppleHealthKit.Constants.Permissions.HeartRate,
      AppleHealthKit.Constants.Permissions.RestingHeartRate,
      AppleHealthKit.Constants.Permissions.HeartRateVariability,
      AppleHealthKit.Constants.Permissions.OxygenSaturation,
      AppleHealthKit.Constants.Permissions.RespiratoryRate,
      AppleHealthKit.Constants.Permissions.BodyTemperature,
      AppleHealthKit.Constants.Permissions.BloodPressureSystolic,
      AppleHealthKit.Constants.Permissions.BloodPressureDiastolic,
      AppleHealthKit.Constants.Permissions.BloodGlucose,
      
      // Body Measurements
      AppleHealthKit.Constants.Permissions.Weight,
      AppleHealthKit.Constants.Permissions.Height,
      AppleHealthKit.Constants.Permissions.BodyMassIndex,
      AppleHealthKit.Constants.Permissions.BodyFatPercentage,
      AppleHealthKit.Constants.Permissions.LeanBodyMass,
      
      // Sleep
      AppleHealthKit.Constants.Permissions.SleepAnalysis,
      
      // Mindfulness
      AppleHealthKit.Constants.Permissions.MindfulSession,
    ],
    write: [
      AppleHealthKit.Constants.Permissions.Steps,
      AppleHealthKit.Constants.Permissions.Weight,
      AppleHealthKit.Constants.Permissions.Workout,
      AppleHealthKit.Constants.Permissions.ActiveEnergyBurned,
      AppleHealthKit.Constants.Permissions.MindfulSession,
    ],
  },
};

export interface HealthMetrics {
  steps: number;
  distance: number; // meters
  activeCalories: number;
  totalCalories: number;
  flightsClimbed: number;
  exerciseMinutes: number;
}

export interface HeartRateData {
  current: number;
  resting: number;
  average: number;
  min: number;
  max: number;
  samples: Array<{ value: number; timestamp: Date }>;
}

export interface SleepData {
  totalMinutes: number;
  inBedMinutes: number;
  awakeMinutes: number;
  remMinutes: number;
  deepMinutes: number;
  lightMinutes: number;
  sleepScore: number;
  sessions: Array<{
    startDate: Date;
    endDate: Date;
    type: 'inBed' | 'asleep' | 'awake' | 'rem' | 'deep' | 'light';
  }>;
}

export interface VitalsData {
  bloodPressure: { systolic: number; diastolic: number } | null;
  bloodGlucose: number | null;
  oxygenSaturation: number | null;
  respiratoryRate: number | null;
  bodyTemperature: number | null;
}

export interface BodyMeasurements {
  weight: number | null; // kg
  height: number | null; // cm
  bmi: number | null;
  bodyFatPercentage: number | null;
}

class AppleHealthKitService {
  private isInitialized: boolean = false;
  private observers: Map<string, any> = new Map();

  /**
   * Initialize HealthKit and request permissions
   */
  async initialize(): Promise<boolean> {
    return new Promise((resolve, reject) => {
      AppleHealthKit.initHealthKit(HEALTHKIT_PERMISSIONS, (error: string) => {
        if (error) {
          console.error('[HealthKit] Initialization error:', error);
          reject(new Error(error));
          return;
        }
        
        console.log('[HealthKit] Initialized successfully');
        this.isInitialized = true;
        resolve(true);
      });
    });
  }

  /**
   * Check if HealthKit is available on this device
   */
  isAvailable(): Promise<boolean> {
    return new Promise((resolve) => {
      AppleHealthKit.isAvailable((error: Object, available: boolean) => {
        resolve(available && !error);
      });
    });
  }

  /**
   * Get today's activity metrics (steps, distance, calories, etc.)
   */
  async getTodayActivity(): Promise<HealthMetrics> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const options: HealthInputOptions = {
      startDate: today.toISOString(),
      endDate: new Date().toISOString(),
    };

    const [steps, distance, activeCalories, flightsClimbed] = await Promise.all([
      this.getStepCount(options),
      this.getDistanceWalkingRunning(options),
      this.getActiveEnergyBurned(options),
      this.getFlightsClimbed(options),
    ]);

    return {
      steps,
      distance,
      activeCalories,
      totalCalories: activeCalories, // Simplified
      flightsClimbed,
      exerciseMinutes: 0, // Would need separate call
    };
  }

  /**
   * Get step count for a period
   */
  private getStepCount(options: HealthInputOptions): Promise<number> {
    return new Promise((resolve) => {
      AppleHealthKit.getStepCount(options, (error: string, results: HealthValue) => {
        if (error) {
          console.warn('[HealthKit] Steps error:', error);
          resolve(0);
          return;
        }
        resolve(results?.value || 0);
      });
    });
  }

  /**
   * Get walking/running distance
   */
  private getDistanceWalkingRunning(options: HealthInputOptions): Promise<number> {
    return new Promise((resolve) => {
      AppleHealthKit.getDistanceWalkingRunning(options, (error: string, results: HealthValue) => {
        if (error) {
          resolve(0);
          return;
        }
        resolve(results?.value || 0);
      });
    });
  }

  /**
   * Get active energy burned
   */
  private getActiveEnergyBurned(options: HealthInputOptions): Promise<number> {
    return new Promise((resolve) => {
      AppleHealthKit.getActiveEnergyBurned(options, (error: string, results: any[]) => {
        if (error || !results) {
          resolve(0);
          return;
        }
        const total = results.reduce((sum, item) => sum + (item.value || 0), 0);
        resolve(total);
      });
    });
  }

  /**
   * Get flights climbed
   */
  private getFlightsClimbed(options: HealthInputOptions): Promise<number> {
    return new Promise((resolve) => {
      AppleHealthKit.getFlightsClimbed(options, (error: string, results: HealthValue) => {
        if (error) {
          resolve(0);
          return;
        }
        resolve(results?.value || 0);
      });
    });
  }

  /**
   * Get heart rate data
   */
  async getHeartRate(startDate?: Date): Promise<HeartRateData> {
    const start = startDate || new Date(Date.now() - 24 * 60 * 60 * 1000); // Last 24 hours
    
    const options: HealthInputOptions = {
      startDate: start.toISOString(),
      endDate: new Date().toISOString(),
      ascending: false,
      limit: 100,
    };

    return new Promise((resolve) => {
      AppleHealthKit.getHeartRateSamples(options, (error: string, results: any[]) => {
        if (error || !results || results.length === 0) {
          resolve({
            current: 0,
            resting: 0,
            average: 0,
            min: 0,
            max: 0,
            samples: [],
          });
          return;
        }

        const values = results.map(r => r.value);
        const samples = results.map(r => ({
          value: r.value,
          timestamp: new Date(r.startDate),
        }));

        resolve({
          current: values[0] || 0,
          resting: 0, // Would need separate call for resting HR
          average: values.reduce((a, b) => a + b, 0) / values.length,
          min: Math.min(...values),
          max: Math.max(...values),
          samples,
        });
      });
    });
  }

  /**
   * Get sleep analysis data
   */
  async getSleepAnalysis(startDate?: Date): Promise<SleepData> {
    const start = startDate || new Date(Date.now() - 24 * 60 * 60 * 1000);
    
    const options: HealthInputOptions = {
      startDate: start.toISOString(),
      endDate: new Date().toISOString(),
    };

    return new Promise((resolve) => {
      AppleHealthKit.getSleepSamples(options, (error: string, results: any[]) => {
        if (error || !results || results.length === 0) {
          resolve({
            totalMinutes: 0,
            inBedMinutes: 0,
            awakeMinutes: 0,
            remMinutes: 0,
            deepMinutes: 0,
            lightMinutes: 0,
            sleepScore: 0,
            sessions: [],
          });
          return;
        }

        let totalMinutes = 0;
        let inBedMinutes = 0;
        let awakeMinutes = 0;
        let asleepMinutes = 0;

        const sessions = results.map(sample => {
          const start = new Date(sample.startDate);
          const end = new Date(sample.endDate);
          const duration = (end.getTime() - start.getTime()) / (1000 * 60);

          if (sample.value === 'INBED') {
            inBedMinutes += duration;
          } else if (sample.value === 'ASLEEP') {
            asleepMinutes += duration;
            totalMinutes += duration;
          } else if (sample.value === 'AWAKE') {
            awakeMinutes += duration;
          }

          return {
            startDate: start,
            endDate: end,
            type: sample.value.toLowerCase() as any,
          };
        });

        // Calculate sleep score (simplified)
        const sleepScore = Math.min(100, Math.round((totalMinutes / 480) * 100)); // 8 hours = 100%

        resolve({
          totalMinutes,
          inBedMinutes,
          awakeMinutes,
          remMinutes: 0, // Would need more detailed sleep stages
          deepMinutes: 0,
          lightMinutes: asleepMinutes,
          sleepScore,
          sessions,
        });
      });
    });
  }

  /**
   * Get body measurements
   */
  async getBodyMeasurements(): Promise<BodyMeasurements> {
    const [weight, height, bmi, bodyFat] = await Promise.all([
      this.getLatestWeight(),
      this.getLatestHeight(),
      this.getLatestBMI(),
      this.getLatestBodyFat(),
    ]);

    return {
      weight,
      height,
      bmi,
      bodyFatPercentage: bodyFat,
    };
  }

  private getLatestWeight(): Promise<number | null> {
    return new Promise((resolve) => {
      AppleHealthKit.getLatestWeight({}, (error: string, results: HealthValue) => {
        if (error || !results) {
          resolve(null);
          return;
        }
        // Convert from pounds to kg
        resolve(results.value * 0.453592);
      });
    });
  }

  private getLatestHeight(): Promise<number | null> {
    return new Promise((resolve) => {
      AppleHealthKit.getLatestHeight({}, (error: string, results: HealthValue) => {
        if (error || !results) {
          resolve(null);
          return;
        }
        // Convert from inches to cm
        resolve(results.value * 2.54);
      });
    });
  }

  private getLatestBMI(): Promise<number | null> {
    return new Promise((resolve) => {
      AppleHealthKit.getLatestBmi({}, (error: string, results: HealthValue) => {
        if (error || !results) {
          resolve(null);
          return;
        }
        resolve(results.value);
      });
    });
  }

  private getLatestBodyFat(): Promise<number | null> {
    return new Promise((resolve) => {
      AppleHealthKit.getLatestBodyFatPercentage({}, (error: string, results: HealthValue) => {
        if (error || !results) {
          resolve(null);
          return;
        }
        resolve(results.value * 100); // Convert to percentage
      });
    });
  }

  /**
   * Get vitals data (blood pressure, glucose, etc.)
   */
  async getVitals(): Promise<VitalsData> {
    const options: HealthInputOptions = {
      startDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(), // Last 7 days
      endDate: new Date().toISOString(),
      ascending: false,
      limit: 1,
    };

    return {
      bloodPressure: null, // Would need separate implementation
      bloodGlucose: null,
      oxygenSaturation: null,
      respiratoryRate: null,
      bodyTemperature: null,
    };
  }

  /**
   * Save a workout to HealthKit
   */
  async saveWorkout(
    type: string,
    startDate: Date,
    endDate: Date,
    calories: number,
    distance?: number
  ): Promise<boolean> {
    const options = {
      type, // e.g., 'Running', 'Walking', 'Cycling'
      startDate: startDate.toISOString(),
      endDate: endDate.toISOString(),
      energyBurned: calories,
      distance: distance || 0,
    };

    return new Promise((resolve) => {
      AppleHealthKit.saveWorkout(options, (error: string, result: any) => {
        if (error) {
          console.error('[HealthKit] Save workout error:', error);
          resolve(false);
          return;
        }
        resolve(true);
      });
    });
  }

  /**
   * Set up background observer for health data changes
   */
  setupBackgroundObserver(
    dataType: string,
    callback: (data: any) => void
  ): void {
    // Note: Background observers require additional setup in native code
    console.log(`[HealthKit] Background observer setup for ${dataType}`);
  }

  /**
   * Get historical data for charts
   */
  async getHistoricalSteps(days: number = 7): Promise<Array<{ date: string; value: number }>> {
    const results: Array<{ date: string; value: number }> = [];
    
    for (let i = days - 1; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      date.setHours(0, 0, 0, 0);
      
      const endDate = new Date(date);
      endDate.setHours(23, 59, 59, 999);
      
      const steps = await this.getStepCount({
        startDate: date.toISOString(),
        endDate: endDate.toISOString(),
      });
      
      results.push({
        date: date.toISOString().split('T')[0],
        value: steps,
      });
    }
    
    return results;
  }

  /**
   * Clean up observers
   */
  cleanup(): void {
    this.observers.forEach((observer, key) => {
      // Clean up observer
    });
    this.observers.clear();
  }
}

export const appleHealthKitService = new AppleHealthKitService();
export default appleHealthKitService;
