/**
 * Android Health Connect Service
 * Native Android health data integration using Health Connect API
 * 
 * Health Connect is the modern standard for Android (replaces Google Fit)
 * No OAuth required - uses on-device permissions
 */

import {
  initialize,
  requestPermission,
  readRecords,
  getSdkStatus,
  SdkAvailabilityStatus,
  Permission,
} from 'react-native-health-connect';

// Health Connect permission types
const HEALTH_CONNECT_PERMISSIONS: Permission[] = [
  // Activity
  { accessType: 'read', recordType: 'Steps' },
  { accessType: 'read', recordType: 'Distance' },
  { accessType: 'read', recordType: 'TotalCaloriesBurned' },
  { accessType: 'read', recordType: 'ActiveCaloriesBurned' },
  { accessType: 'read', recordType: 'FloorsClimbed' },
  { accessType: 'read', recordType: 'ExerciseSession' },
  
  // Heart & Vitals
  { accessType: 'read', recordType: 'HeartRate' },
  { accessType: 'read', recordType: 'RestingHeartRate' },
  { accessType: 'read', recordType: 'HeartRateVariabilityRmssd' },
  { accessType: 'read', recordType: 'OxygenSaturation' },
  { accessType: 'read', recordType: 'RespiratoryRate' },
  { accessType: 'read', recordType: 'BodyTemperature' },
  { accessType: 'read', recordType: 'BloodPressure' },
  { accessType: 'read', recordType: 'BloodGlucose' },
  
  // Body Measurements
  { accessType: 'read', recordType: 'Weight' },
  { accessType: 'read', recordType: 'Height' },
  { accessType: 'read', recordType: 'BodyFat' },
  { accessType: 'read', recordType: 'LeanBodyMass' },
  
  // Sleep
  { accessType: 'read', recordType: 'SleepSession' },
  
  // Write permissions
  { accessType: 'write', recordType: 'Steps' },
  { accessType: 'write', recordType: 'Weight' },
  { accessType: 'write', recordType: 'ExerciseSession' },
  { accessType: 'write', recordType: 'ActiveCaloriesBurned' },
];

export interface HealthMetrics {
  steps: number;
  distance: number; // meters
  activeCalories: number;
  totalCalories: number;
  flightsClimbed: number;
  exerciseMinutes: number;
}

export interface HeartRateData {
  current: number;
  resting: number;
  average: number;
  min: number;
  max: number;
  samples: Array<{ value: number; timestamp: Date }>;
}

export interface SleepData {
  totalMinutes: number;
  inBedMinutes: number;
  awakeMinutes: number;
  remMinutes: number;
  deepMinutes: number;
  lightMinutes: number;
  sleepScore: number;
  sessions: Array<{
    startDate: Date;
    endDate: Date;
    type: 'inBed' | 'asleep' | 'awake' | 'rem' | 'deep' | 'light';
  }>;
}

export interface VitalsData {
  bloodPressure: { systolic: number; diastolic: number } | null;
  bloodGlucose: number | null;
  oxygenSaturation: number | null;
  respiratoryRate: number | null;
  bodyTemperature: number | null;
}

export interface BodyMeasurements {
  weight: number | null; // kg
  height: number | null; // cm
  bmi: number | null;
  bodyFatPercentage: number | null;
}

class HealthConnectService {
  private isInitialized: boolean = false;
  private sdkStatus: SdkAvailabilityStatus | null = null;

  /**
   * Check if Health Connect is available and get SDK status
   */
  async checkAvailability(): Promise<{
    available: boolean;
    status: string;
    needsInstall: boolean;
    needsUpdate: boolean;
  }> {
    try {
      const status = await getSdkStatus();
      this.sdkStatus = status;
      
      return {
        available: status === SdkAvailabilityStatus.SDK_AVAILABLE,
        status: this.getStatusMessage(status),
        needsInstall: status === SdkAvailabilityStatus.SDK_UNAVAILABLE,
        needsUpdate: status === SdkAvailabilityStatus.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED,
      };
    } catch (error) {
      console.error('[HealthConnect] Availability check error:', error);
      return {
        available: false,
        status: 'Error checking Health Connect availability',
        needsInstall: true,
        needsUpdate: false,
      };
    }
  }

  private getStatusMessage(status: SdkAvailabilityStatus): string {
    switch (status) {
      case SdkAvailabilityStatus.SDK_AVAILABLE:
        return 'Health Connect is available';
      case SdkAvailabilityStatus.SDK_UNAVAILABLE:
        return 'Health Connect is not installed';
      case SdkAvailabilityStatus.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED:
        return 'Health Connect needs to be updated';
      default:
        return 'Unknown status';
    }
  }

  /**
   * Initialize Health Connect and request permissions
   */
  async initialize(): Promise<boolean> {
    try {
      // Check availability first
      const availability = await this.checkAvailability();
      if (!availability.available) {
        console.warn('[HealthConnect] Not available:', availability.status);
        return false;
      }

      // Initialize the SDK
      const initialized = await initialize();
      if (!initialized) {
        console.error('[HealthConnect] Failed to initialize');
        return false;
      }

      this.isInitialized = true;
      console.log('[HealthConnect] Initialized successfully');
      return true;
    } catch (error) {
      console.error('[HealthConnect] Initialization error:', error);
      return false;
    }
  }

  /**
   * Request health data permissions from user
   */
  async requestPermissions(): Promise<boolean> {
    try {
      const granted = await requestPermission(HEALTH_CONNECT_PERMISSIONS);
      console.log('[HealthConnect] Permissions granted:', granted);
      return granted.length > 0;
    } catch (error) {
      console.error('[HealthConnect] Permission request error:', error);
      return false;
    }
  }

  /**
   * Get today's activity metrics
   */
  async getTodayActivity(): Promise<HealthMetrics> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const now = new Date();

    const timeRangeFilter = {
      operator: 'between' as const,
      startTime: today.toISOString(),
      endTime: now.toISOString(),
    };

    try {
      const [stepsData, distanceData, caloriesData, floorsData] = await Promise.all([
        this.readSteps(timeRangeFilter),
        this.readDistance(timeRangeFilter),
        this.readCalories(timeRangeFilter),
        this.readFloorsClimbed(timeRangeFilter),
      ]);

      return {
        steps: stepsData,
        distance: distanceData,
        activeCalories: caloriesData,
        totalCalories: caloriesData,
        flightsClimbed: floorsData,
        exerciseMinutes: 0, // Would need exercise sessions
      };
    } catch (error) {
      console.error('[HealthConnect] Activity read error:', error);
      return {
        steps: 0,
        distance: 0,
        activeCalories: 0,
        totalCalories: 0,
        flightsClimbed: 0,
        exerciseMinutes: 0,
      };
    }
  }

  /**
   * Read step count
   */
  private async readSteps(timeRangeFilter: any): Promise<number> {
    try {
      const result = await readRecords('Steps', { timeRangeFilter });
      return result.records.reduce((sum: number, record: any) => sum + record.count, 0);
    } catch (error) {
      console.warn('[HealthConnect] Steps read error:', error);
      return 0;
    }
  }

  /**
   * Read distance
   */
  private async readDistance(timeRangeFilter: any): Promise<number> {
    try {
      const result = await readRecords('Distance', { timeRangeFilter });
      return result.records.reduce((sum: number, record: any) => 
        sum + (record.distance?.inMeters || 0), 0);
    } catch (error) {
      console.warn('[HealthConnect] Distance read error:', error);
      return 0;
    }
  }

  /**
   * Read calories burned
   */
  private async readCalories(timeRangeFilter: any): Promise<number> {
    try {
      const result = await readRecords('ActiveCaloriesBurned', { timeRangeFilter });
      return result.records.reduce((sum: number, record: any) => 
        sum + (record.energy?.inKilocalories || 0), 0);
    } catch (error) {
      console.warn('[HealthConnect] Calories read error:', error);
      return 0;
    }
  }

  /**
   * Read floors climbed
   */
  private async readFloorsClimbed(timeRangeFilter: any): Promise<number> {
    try {
      const result = await readRecords('FloorsClimbed', { timeRangeFilter });
      return result.records.reduce((sum: number, record: any) => sum + record.floors, 0);
    } catch (error) {
      console.warn('[HealthConnect] Floors read error:', error);
      return 0;
    }
  }

  /**
   * Get heart rate data
   */
  async getHeartRate(startDate?: Date): Promise<HeartRateData> {
    const start = startDate || new Date(Date.now() - 24 * 60 * 60 * 1000);
    const timeRangeFilter = {
      operator: 'between' as const,
      startTime: start.toISOString(),
      endTime: new Date().toISOString(),
    };

    try {
      const result = await readRecords('HeartRate', { timeRangeFilter });
      
      if (!result.records || result.records.length === 0) {
        return this.getEmptyHeartRateData();
      }

      const samples: Array<{ value: number; timestamp: Date }> = [];
      const values: number[] = [];

      result.records.forEach((record: any) => {
        record.samples?.forEach((sample: any) => {
          values.push(sample.beatsPerMinute);
          samples.push({
            value: sample.beatsPerMinute,
            timestamp: new Date(sample.time),
          });
        });
      });

      if (values.length === 0) {
        return this.getEmptyHeartRateData();
      }

      // Get resting heart rate
      let restingHR = 0;
      try {
        const restingResult = await readRecords('RestingHeartRate', { timeRangeFilter });
        if (restingResult.records && restingResult.records.length > 0) {
          restingHR = restingResult.records[restingResult.records.length - 1].beatsPerMinute;
        }
      } catch (e) {
        // Resting HR not available
      }

      return {
        current: values[values.length - 1],
        resting: restingHR,
        average: Math.round(values.reduce((a, b) => a + b, 0) / values.length),
        min: Math.min(...values),
        max: Math.max(...values),
        samples: samples.slice(-50), // Last 50 samples
      };
    } catch (error) {
      console.error('[HealthConnect] Heart rate read error:', error);
      return this.getEmptyHeartRateData();
    }
  }

  private getEmptyHeartRateData(): HeartRateData {
    return {
      current: 0,
      resting: 0,
      average: 0,
      min: 0,
      max: 0,
      samples: [],
    };
  }

  /**
   * Get sleep analysis data
   */
  async getSleepAnalysis(startDate?: Date): Promise<SleepData> {
    const start = startDate || new Date(Date.now() - 24 * 60 * 60 * 1000);
    const timeRangeFilter = {
      operator: 'between' as const,
      startTime: start.toISOString(),
      endTime: new Date().toISOString(),
    };

    try {
      const result = await readRecords('SleepSession', { timeRangeFilter });
      
      if (!result.records || result.records.length === 0) {
        return this.getEmptySleepData();
      }

      let totalMinutes = 0;
      let awakeMinutes = 0;
      let remMinutes = 0;
      let deepMinutes = 0;
      let lightMinutes = 0;
      const sessions: SleepData['sessions'] = [];

      result.records.forEach((record: any) => {
        const start = new Date(record.startTime);
        const end = new Date(record.endTime);
        const duration = (end.getTime() - start.getTime()) / (1000 * 60);
        
        totalMinutes += duration;

        // Process sleep stages if available
        record.stages?.forEach((stage: any) => {
          const stageStart = new Date(stage.startTime);
          const stageEnd = new Date(stage.endTime);
          const stageDuration = (stageEnd.getTime() - stageStart.getTime()) / (1000 * 60);

          let type: 'awake' | 'light' | 'deep' | 'rem' | 'asleep' | 'inBed' = 'asleep';
          
          switch (stage.stage) {
            case 1: // AWAKE
              awakeMinutes += stageDuration;
              type = 'awake';
              break;
            case 2: // SLEEPING
              lightMinutes += stageDuration;
              type = 'asleep';
              break;
            case 3: // OUT_OF_BED
              type = 'awake';
              break;
            case 4: // LIGHT
              lightMinutes += stageDuration;
              type = 'light';
              break;
            case 5: // DEEP
              deepMinutes += stageDuration;
              type = 'deep';
              break;
            case 6: // REM
              remMinutes += stageDuration;
              type = 'rem';
              break;
          }

          sessions.push({
            startDate: stageStart,
            endDate: stageEnd,
            type,
          });
        });
      });

      // Calculate sleep score (simplified)
      const sleepScore = Math.min(100, Math.round((totalMinutes / 480) * 100));

      return {
        totalMinutes: Math.round(totalMinutes),
        inBedMinutes: Math.round(totalMinutes + awakeMinutes),
        awakeMinutes: Math.round(awakeMinutes),
        remMinutes: Math.round(remMinutes),
        deepMinutes: Math.round(deepMinutes),
        lightMinutes: Math.round(lightMinutes),
        sleepScore,
        sessions,
      };
    } catch (error) {
      console.error('[HealthConnect] Sleep read error:', error);
      return this.getEmptySleepData();
    }
  }

  private getEmptySleepData(): SleepData {
    return {
      totalMinutes: 0,
      inBedMinutes: 0,
      awakeMinutes: 0,
      remMinutes: 0,
      deepMinutes: 0,
      lightMinutes: 0,
      sleepScore: 0,
      sessions: [],
    };
  }

  /**
   * Get body measurements
   */
  async getBodyMeasurements(): Promise<BodyMeasurements> {
    const timeRangeFilter = {
      operator: 'between' as const,
      startTime: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(), // Last 30 days
      endTime: new Date().toISOString(),
    };

    let weight: number | null = null;
    let height: number | null = null;
    let bodyFat: number | null = null;

    try {
      const weightResult = await readRecords('Weight', { timeRangeFilter });
      if (weightResult.records && weightResult.records.length > 0) {
        const latest = weightResult.records[weightResult.records.length - 1];
        weight = latest.weight?.inKilograms || null;
      }
    } catch (e) {}

    try {
      const heightResult = await readRecords('Height', { timeRangeFilter });
      if (heightResult.records && heightResult.records.length > 0) {
        const latest = heightResult.records[heightResult.records.length - 1];
        height = (latest.height?.inMeters || 0) * 100; // Convert to cm
      }
    } catch (e) {}

    try {
      const bodyFatResult = await readRecords('BodyFat', { timeRangeFilter });
      if (bodyFatResult.records && bodyFatResult.records.length > 0) {
        const latest = bodyFatResult.records[bodyFatResult.records.length - 1];
        bodyFat = latest.percentage;
      }
    } catch (e) {}

    // Calculate BMI
    let bmi: number | null = null;
    if (weight && height) {
      const heightInMeters = height / 100;
      bmi = Math.round((weight / (heightInMeters * heightInMeters)) * 10) / 10;
    }

    return {
      weight,
      height,
      bmi,
      bodyFatPercentage: bodyFat,
    };
  }

  /**
   * Get vitals data
   */
  async getVitals(): Promise<VitalsData> {
    const timeRangeFilter = {
      operator: 'between' as const,
      startTime: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
      endTime: new Date().toISOString(),
    };

    let bloodPressure: VitalsData['bloodPressure'] = null;
    let bloodGlucose: number | null = null;
    let oxygenSaturation: number | null = null;
    let respiratoryRate: number | null = null;
    let bodyTemperature: number | null = null;

    try {
      const bpResult = await readRecords('BloodPressure', { timeRangeFilter });
      if (bpResult.records && bpResult.records.length > 0) {
        const latest = bpResult.records[bpResult.records.length - 1];
        bloodPressure = {
          systolic: latest.systolic?.inMillimetersOfMercury || 0,
          diastolic: latest.diastolic?.inMillimetersOfMercury || 0,
        };
      }
    } catch (e) {}

    try {
      const bgResult = await readRecords('BloodGlucose', { timeRangeFilter });
      if (bgResult.records && bgResult.records.length > 0) {
        const latest = bgResult.records[bgResult.records.length - 1];
        bloodGlucose = latest.level?.inMilligramsPerDeciliter || null;
      }
    } catch (e) {}

    try {
      const o2Result = await readRecords('OxygenSaturation', { timeRangeFilter });
      if (o2Result.records && o2Result.records.length > 0) {
        const latest = o2Result.records[o2Result.records.length - 1];
        oxygenSaturation = latest.percentage;
      }
    } catch (e) {}

    try {
      const rrResult = await readRecords('RespiratoryRate', { timeRangeFilter });
      if (rrResult.records && rrResult.records.length > 0) {
        const latest = rrResult.records[rrResult.records.length - 1];
        respiratoryRate = latest.rate;
      }
    } catch (e) {}

    try {
      const tempResult = await readRecords('BodyTemperature', { timeRangeFilter });
      if (tempResult.records && tempResult.records.length > 0) {
        const latest = tempResult.records[tempResult.records.length - 1];
        bodyTemperature = latest.temperature?.inCelsius || null;
      }
    } catch (e) {}

    return {
      bloodPressure,
      bloodGlucose,
      oxygenSaturation,
      respiratoryRate,
      bodyTemperature,
    };
  }

  /**
   * Get historical steps data for charts
   */
  async getHistoricalSteps(days: number = 7): Promise<Array<{ date: string; value: number }>> {
    const results: Array<{ date: string; value: number }> = [];

    for (let i = days - 1; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      date.setHours(0, 0, 0, 0);
      
      const endDate = new Date(date);
      endDate.setHours(23, 59, 59, 999);

      const timeRangeFilter = {
        operator: 'between' as const,
        startTime: date.toISOString(),
        endTime: endDate.toISOString(),
      };

      const steps = await this.readSteps(timeRangeFilter);
      results.push({
        date: date.toISOString().split('T')[0],
        value: steps,
      });
    }

    return results;
  }

  /**
   * Open Health Connect settings
   */
  openHealthConnectSettings(): void {
    // This would use Linking to open Health Connect app
    // Linking.openSettings() or specific Health Connect intent
  }
}

export const healthConnectService = new HealthConnectService();
export default healthConnectService;
