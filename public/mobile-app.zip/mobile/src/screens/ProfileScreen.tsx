/**
 * Profile Screen
 * User profile, settings, health connections, and logout
 */

import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  Image,
  Alert,
  Platform,
  Linking,
} from 'react-native';
import Icon from 'react-native-vector-icons/Feather';
import AsyncStorage from '@react-native-async-storage/async-storage';
import healthService from '../services/HealthService';
import { API_BASE_URL } from '../utils/config';

interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  avatar_url?: string;
}

interface HealthConnection {
  id: string;
  name: string;
  connected: boolean;
  icon: string;
  color: string;
  lastSync?: string;
}

interface ProfileScreenProps {
  navigation: any;
}

const ProfileScreen: React.FC<ProfileScreenProps> = ({ navigation }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [healthConnections, setHealthConnections] = useState<HealthConnection[]>([]);
  const [notifications, setNotifications] = useState({
    appointments: true,
    reminders: true,
    wellness: true,
    marketing: false,
  });

  useEffect(() => {
    loadProfile();
    loadHealthConnections();
  }, []);

  const loadProfile = async () => {
    try {
      const token = await AsyncStorage.getItem('auth_token');
      
      if (!token) {
        // Demo user
        setUser({
          id: 'demo-user',
          name: 'Demo User',
          email: 'demo@healthtrackpro.com',
          phone: '+91 9876543210',
        });
        setLoading(false);
        return;
      }

      const response = await fetch(`${API_BASE_URL}/api/auth/me`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (response.ok) {
        const data = await response.json();
        setUser(data.user);
      }
    } catch (err) {
      console.error('Load profile error:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadHealthConnections = async () => {
    const status = await healthService.getStatus();
    
    const connections: HealthConnection[] = [
      {
        id: 'native',
        name: Platform.OS === 'ios' ? 'Apple Health' : 'Health Connect',
        connected: status.initialized && status.permissionsGranted,
        icon: Platform.OS === 'ios' ? 'heart' : 'activity',
        color: Platform.OS === 'ios' ? '#FF3B30' : '#4CAF50',
        lastSync: status.initialized ? 'Connected' : 'Not connected',
      },
    ];

    setHealthConnections(connections);
  };

  const connectHealth = async () => {
    try {
      const success = await healthService.initialize();
      if (success) {
        Alert.alert('Success', 'Health services connected successfully!');
        loadHealthConnections();
      } else {
        Alert.alert(
          'Permission Required',
          'Please grant health permissions in your device settings.'
        );
      }
    } catch (err) {
      Alert.alert('Error', 'Failed to connect health services.');
    }
  };

  const handleLogout = async () => {
    Alert.alert('Logout', 'Are you sure you want to logout?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Logout',
        style: 'destructive',
        onPress: async () => {
          await AsyncStorage.multiRemove([
            'auth_token',
            'user_data',
            'cached_appointments',
            'cached_doctors',
            'cached_wellness_plan',
          ]);
          // Navigate to login
          navigation.reset({
            index: 0,
            routes: [{ name: 'Login' }],
          });
        },
      },
    ]);
  };

  const MenuItem = ({
    icon,
    label,
    value,
    onPress,
    showArrow = true,
    destructive = false,
  }: {
    icon: string;
    label: string;
    value?: string;
    onPress?: () => void;
    showArrow?: boolean;
    destructive?: boolean;
  }) => (
    <TouchableOpacity style={styles.menuItem} onPress={onPress} activeOpacity={0.7}>
      <View style={[styles.menuIcon, destructive && styles.menuIconDestructive]}>
        <Icon name={icon} size={20} color={destructive ? '#F44336' : '#666'} />
      </View>
      <Text style={[styles.menuLabel, destructive && styles.menuLabelDestructive]}>{label}</Text>
      {value && <Text style={styles.menuValue}>{value}</Text>}
      {showArrow && <Icon name="chevron-right" size={20} color="#CCC" />}
    </TouchableOpacity>
  );

  const ToggleItem = ({
    icon,
    label,
    value,
    onValueChange,
  }: {
    icon: string;
    label: string;
    value: boolean;
    onValueChange: (val: boolean) => void;
  }) => (
    <View style={styles.menuItem}>
      <View style={styles.menuIcon}>
        <Icon name={icon} size={20} color="#666" />
      </View>
      <Text style={styles.menuLabel}>{label}</Text>
      <Switch
        value={value}
        onValueChange={onValueChange}
        trackColor={{ false: '#E0E0E0', true: '#FFCCBC' }}
        thumbColor={value ? '#FF6B35' : '#F5F5F5'}
      />
    </View>
  );

  return (
    <ScrollView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Profile</Text>
      </View>

      {/* Profile Card */}
      <View style={styles.profileCard}>
        <View style={styles.avatarContainer}>
          {user?.avatar_url ? (
            <Image source={{ uri: user.avatar_url }} style={styles.avatar} />
          ) : (
            <View style={styles.avatarPlaceholder}>
              <Text style={styles.avatarText}>{user?.name?.charAt(0) || 'U'}</Text>
            </View>
          )}
          <TouchableOpacity style={styles.editAvatarButton}>
            <Icon name="camera" size={14} color="#FFF" />
          </TouchableOpacity>
        </View>
        <Text style={styles.userName}>{user?.name || 'Loading...'}</Text>
        <Text style={styles.userEmail}>{user?.email}</Text>
        <TouchableOpacity style={styles.editProfileButton}>
          <Icon name="edit-2" size={14} color="#FF6B35" />
          <Text style={styles.editProfileText}>Edit Profile</Text>
        </TouchableOpacity>
      </View>

      {/* Health Connections */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Health Connections</Text>
        {healthConnections.map((connection) => (
          <TouchableOpacity
            key={connection.id}
            style={styles.connectionCard}
            onPress={() => !connection.connected && connectHealth()}
          >
            <View style={[styles.connectionIcon, { backgroundColor: connection.color + '20' }]}>
              <Icon name={connection.icon} size={24} color={connection.color} />
            </View>
            <View style={styles.connectionInfo}>
              <Text style={styles.connectionName}>{connection.name}</Text>
              <Text style={styles.connectionStatus}>{connection.lastSync}</Text>
            </View>
            {connection.connected ? (
              <View style={styles.connectedBadge}>
                <Icon name="check" size={14} color="#4CAF50" />
                <Text style={styles.connectedText}>Connected</Text>
              </View>
            ) : (
              <TouchableOpacity style={styles.connectButton} onPress={connectHealth}>
                <Text style={styles.connectButtonText}>Connect</Text>
              </TouchableOpacity>
            )}
          </TouchableOpacity>
        ))}
      </View>

      {/* Notifications */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Notifications</Text>
        <View style={styles.menuCard}>
          <ToggleItem
            icon="calendar"
            label="Appointment Reminders"
            value={notifications.appointments}
            onValueChange={(val) => setNotifications({ ...notifications, appointments: val })}
          />
          <ToggleItem
            icon="bell"
            label="Health Reminders"
            value={notifications.reminders}
            onValueChange={(val) => setNotifications({ ...notifications, reminders: val })}
          />
          <ToggleItem
            icon="heart"
            label="Wellness Tips"
            value={notifications.wellness}
            onValueChange={(val) => setNotifications({ ...notifications, wellness: val })}
          />
          <ToggleItem
            icon="mail"
            label="Marketing Emails"
            value={notifications.marketing}
            onValueChange={(val) => setNotifications({ ...notifications, marketing: val })}
          />
        </View>
      </View>

      {/* Account */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Account</Text>
        <View style={styles.menuCard}>
          <MenuItem icon="user" label="Personal Information" onPress={() => {}} />
          <MenuItem icon="lock" label="Change Password" onPress={() => {}} />
          <MenuItem icon="shield" label="Privacy Settings" onPress={() => {}} />
          <MenuItem icon="file-text" label="Medical Records" onPress={() => {}} />
          <MenuItem icon="credit-card" label="Payment Methods" onPress={() => {}} />
        </View>
      </View>

      {/* Support */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Support</Text>
        <View style={styles.menuCard}>
          <MenuItem
            icon="help-circle"
            label="Help Center"
            onPress={() => Linking.openURL('https://infuse.net.in/help')}
          />
          <MenuItem
            icon="message-circle"
            label="Contact Support"
            onPress={() => Linking.openURL('mailto:support@infuse.net.in')}
          />
          <MenuItem
            icon="file"
            label="Terms of Service"
            onPress={() => Linking.openURL('https://infuse.net.in/terms')}
          />
          <MenuItem
            icon="shield"
            label="Privacy Policy"
            onPress={() => Linking.openURL('https://infuse.net.in/privacy')}
          />
        </View>
      </View>

      {/* App Info */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>App</Text>
        <View style={styles.menuCard}>
          <MenuItem icon="info" label="Version" value="1.0.0" showArrow={false} />
          <MenuItem
            icon="star"
            label="Rate the App"
            onPress={() => {
              Platform.OS === 'ios'
                ? Linking.openURL('https://apps.apple.com/app/healthtrack-pro')
                : Linking.openURL('https://play.google.com/store/apps/details?id=com.infuse.healthtrackpro');
            }}
          />
          <MenuItem
            icon="share-2"
            label="Share with Friends"
            onPress={() => {
              // Share functionality
            }}
          />
        </View>
      </View>

      {/* Logout */}
      <View style={styles.section}>
        <View style={styles.menuCard}>
          <MenuItem icon="log-out" label="Logout" onPress={handleLogout} destructive showArrow={false} />
        </View>
      </View>

      {/* Footer */}
      <View style={styles.footer}>
        <Text style={styles.footerText}>HealthTrack Pro by Infuse</Text>
        <Text style={styles.footerText}>© 2026 All Rights Reserved</Text>
      </View>

      <View style={{ height: 40 }} />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F7FA',
  },
  header: {
    padding: 20,
    paddingTop: Platform.OS === 'ios' ? 60 : 20,
    backgroundColor: '#FFF',
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1A1A1A',
  },
  profileCard: {
    backgroundColor: '#FFF',
    alignItems: 'center',
    padding: 24,
    marginHorizontal: 16,
    marginTop: 16,
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  avatarContainer: {
    position: 'relative',
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
  },
  avatarPlaceholder: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#FF6B35',
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#FFF',
  },
  editAvatarButton: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: '#FF6B35',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#FFF',
  },
  userName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1A1A1A',
    marginTop: 12,
  },
  userEmail: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  editProfileButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 16,
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: '#FFF5F2',
    borderRadius: 20,
  },
  editProfileText: {
    fontSize: 14,
    color: '#FF6B35',
    fontWeight: '500',
    marginLeft: 6,
  },
  section: {
    marginTop: 24,
    paddingHorizontal: 16,
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#999',
    marginBottom: 8,
    marginLeft: 4,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  connectionCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFF',
    padding: 16,
    borderRadius: 12,
    marginBottom: 8,
  },
  connectionIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  connectionInfo: {
    flex: 1,
    marginLeft: 12,
  },
  connectionName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1A1A1A',
  },
  connectionStatus: {
    fontSize: 12,
    color: '#666',
    marginTop: 2,
  },
  connectedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#E8F5E9',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  connectedText: {
    fontSize: 12,
    color: '#4CAF50',
    marginLeft: 4,
  },
  connectButton: {
    backgroundColor: '#FF6B35',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 16,
  },
  connectButtonText: {
    color: '#FFF',
    fontSize: 12,
    fontWeight: '600',
  },
  menuCard: {
    backgroundColor: '#FFF',
    borderRadius: 12,
    overflow: 'hidden',
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F5F5F5',
  },
  menuIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#F5F7FA',
    justifyContent: 'center',
    alignItems: 'center',
  },
  menuIconDestructive: {
    backgroundColor: '#FFEBEE',
  },
  menuLabel: {
    flex: 1,
    fontSize: 16,
    color: '#1A1A1A',
    marginLeft: 12,
  },
  menuLabelDestructive: {
    color: '#F44336',
  },
  menuValue: {
    fontSize: 14,
    color: '#999',
    marginRight: 8,
  },
  footer: {
    alignItems: 'center',
    paddingVertical: 24,
  },
  footerText: {
    fontSize: 12,
    color: '#999',
    marginTop: 4,
  },
});

export default ProfileScreen;
