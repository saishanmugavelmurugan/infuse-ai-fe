/**
 * Appointments Screen
 * View upcoming and past appointments
 * Book new appointments
 */

import React, { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  Platform,
  Alert,
} from 'react-native';
import Icon from 'react-native-vector-icons/Feather';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { API_BASE_URL } from '../utils/config';

interface Appointment {
  id: string;
  doctor_id: string;
  doctor_name: string;
  doctor_specialty: string;
  appointment_date: string;
  appointment_time: string;
  consultation_type: 'video' | 'audio' | 'in_person';
  status: 'scheduled' | 'completed' | 'cancelled' | 'in_progress';
  reason: string;
  notes?: string;
  consultation_fee: number;
}

interface AppointmentsScreenProps {
  navigation: any;
}

const AppointmentsScreen: React.FC<AppointmentsScreenProps> = ({ navigation }) => {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [activeTab, setActiveTab] = useState<'upcoming' | 'past'>('upcoming');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchAppointments();
  }, []);

  const fetchAppointments = async () => {
    try {
      setError(null);
      const token = await AsyncStorage.getItem('auth_token');
      
      if (!token) {
        // Show demo data if not logged in
        setAppointments(getDemoAppointments());
        setLoading(false);
        return;
      }

      const response = await fetch(`${API_BASE_URL}/api/healthtrack/appointments`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        throw new Error('Failed to fetch appointments');
      }

      const data = await response.json();
      setAppointments(data.appointments || []);
      
      // Cache for offline
      await AsyncStorage.setItem('cached_appointments', JSON.stringify(data.appointments || []));
    } catch (err) {
      console.error('Fetch appointments error:', err);
      
      // Try cache
      const cached = await AsyncStorage.getItem('cached_appointments');
      if (cached) {
        setAppointments(JSON.parse(cached));
        setError('Showing cached data');
      } else {
        setAppointments(getDemoAppointments());
      }
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const getDemoAppointments = (): Appointment[] => {
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const nextWeek = new Date(today);
    nextWeek.setDate(nextWeek.getDate() + 7);
    const lastWeek = new Date(today);
    lastWeek.setDate(lastWeek.getDate() - 7);

    return [
      {
        id: 'demo-1',
        doctor_id: 'doc-1',
        doctor_name: 'Dr. Priya Sharma',
        doctor_specialty: 'Cardiology',
        appointment_date: tomorrow.toISOString().split('T')[0],
        appointment_time: '10:00',
        consultation_type: 'video',
        status: 'scheduled',
        reason: 'Annual heart checkup',
        consultation_fee: 800,
      },
      {
        id: 'demo-2',
        doctor_id: 'doc-2',
        doctor_name: 'Dr. Rajesh Kumar',
        doctor_specialty: 'General Medicine',
        appointment_date: nextWeek.toISOString().split('T')[0],
        appointment_time: '14:30',
        consultation_type: 'in_person',
        status: 'scheduled',
        reason: 'Follow-up consultation',
        consultation_fee: 500,
      },
      {
        id: 'demo-3',
        doctor_id: 'doc-3',
        doctor_name: 'Dr. Anita Desai',
        doctor_specialty: 'Ayurveda',
        appointment_date: lastWeek.toISOString().split('T')[0],
        appointment_time: '11:00',
        consultation_type: 'video',
        status: 'completed',
        reason: 'Lifestyle consultation',
        consultation_fee: 600,
      },
    ];
  };

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    fetchAppointments();
  }, []);

  const cancelAppointment = async (id: string) => {
    Alert.alert(
      'Cancel Appointment',
      'Are you sure you want to cancel this appointment?',
      [
        { text: 'No', style: 'cancel' },
        {
          text: 'Yes, Cancel',
          style: 'destructive',
          onPress: async () => {
            try {
              const token = await AsyncStorage.getItem('auth_token');
              await fetch(`${API_BASE_URL}/api/healthtrack/appointments/${id}/cancel`, {
                method: 'POST',
                headers: {
                  'Authorization': `Bearer ${token}`,
                },
              });
              fetchAppointments();
            } catch (err) {
              Alert.alert('Error', 'Failed to cancel appointment');
            }
          },
        },
      ]
    );
  };

  const getFilteredAppointments = () => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    if (activeTab === 'upcoming') {
      return appointments.filter((apt) => {
        const aptDate = new Date(apt.appointment_date);
        return aptDate >= today && apt.status !== 'cancelled' && apt.status !== 'completed';
      });
    } else {
      return appointments.filter((apt) => {
        const aptDate = new Date(apt.appointment_date);
        return aptDate < today || apt.status === 'completed' || apt.status === 'cancelled';
      });
    }
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    if (date.toDateString() === today.toDateString()) {
      return 'Today';
    } else if (date.toDateString() === tomorrow.toDateString()) {
      return 'Tomorrow';
    } else {
      return date.toLocaleDateString('en-US', {
        weekday: 'short',
        month: 'short',
        day: 'numeric',
      });
    }
  };

  const formatTime = (time: string) => {
    const [hours, minutes] = time.split(':');
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 || 12;
    return `${displayHour}:${minutes} ${ampm}`;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'scheduled':
        return '#4CAF50';
      case 'in_progress':
        return '#2196F3';
      case 'completed':
        return '#9E9E9E';
      case 'cancelled':
        return '#F44336';
      default:
        return '#666';
    }
  };

  const getConsultationIcon = (type: string) => {
    switch (type) {
      case 'video':
        return 'video';
      case 'audio':
        return 'phone';
      case 'in_person':
        return 'map-pin';
      default:
        return 'calendar';
    }
  };

  const renderAppointment = ({ item }: { item: Appointment }) => (
    <TouchableOpacity
      style={styles.appointmentCard}
      onPress={() => navigation.navigate('AppointmentDetail', { appointment: item })}
      activeOpacity={0.7}
    >
      <View style={styles.appointmentHeader}>
        <View style={styles.dateContainer}>
          <Text style={styles.dateText}>{formatDate(item.appointment_date)}</Text>
          <Text style={styles.timeText}>{formatTime(item.appointment_time)}</Text>
        </View>
        <View style={[styles.statusBadge, { backgroundColor: getStatusColor(item.status) + '20' }]}>
          <View style={[styles.statusDot, { backgroundColor: getStatusColor(item.status) }]} />
          <Text style={[styles.statusText, { color: getStatusColor(item.status) }]}>
            {item.status.replace('_', ' ')}
          </Text>
        </View>
      </View>

      <View style={styles.doctorInfo}>
        <View style={styles.avatarSmall}>
          <Text style={styles.avatarSmallText}>{item.doctor_name.charAt(0)}</Text>
        </View>
        <View style={styles.doctorDetails}>
          <Text style={styles.doctorName}>{item.doctor_name}</Text>
          <Text style={styles.doctorSpecialty}>{item.doctor_specialty}</Text>
        </View>
        <View style={styles.consultationType}>
          <Icon name={getConsultationIcon(item.consultation_type)} size={16} color="#666" />
          <Text style={styles.consultationText}>{item.consultation_type.replace('_', ' ')}</Text>
        </View>
      </View>

      <View style={styles.appointmentDetails}>
        <Text style={styles.reasonText} numberOfLines={1}>
          {item.reason}
        </Text>
        <Text style={styles.feeText}>₹{item.consultation_fee}</Text>
      </View>

      {item.status === 'scheduled' && (
        <View style={styles.actionButtons}>
          {item.consultation_type === 'video' && (
            <TouchableOpacity style={styles.joinButton}>
              <Icon name="video" size={16} color="#FFF" />
              <Text style={styles.joinButtonText}>Join Call</Text>
            </TouchableOpacity>
          )}
          <TouchableOpacity
            style={styles.rescheduleButton}
            onPress={() => navigation.navigate('BookAppointment', { reschedule: item.id })}
          >
            <Icon name="calendar" size={16} color="#FF6B35" />
            <Text style={styles.rescheduleButtonText}>Reschedule</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.cancelButton}
            onPress={() => cancelAppointment(item.id)}
          >
            <Icon name="x" size={16} color="#F44336" />
          </TouchableOpacity>
        </View>
      )}
    </TouchableOpacity>
  );

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#FF6B35" />
        <Text style={styles.loadingText}>Loading appointments...</Text>
      </View>
    );
  }

  const filteredAppointments = getFilteredAppointments();

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Appointments</Text>
        <TouchableOpacity
          style={styles.addButton}
          onPress={() => navigation.navigate('Doctors')}
        >
          <Icon name="plus" size={24} color="#FFF" />
        </TouchableOpacity>
      </View>

      {/* Tabs */}
      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'upcoming' && styles.tabActive]}
          onPress={() => setActiveTab('upcoming')}
        >
          <Text style={[styles.tabText, activeTab === 'upcoming' && styles.tabTextActive]}>
            Upcoming
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'past' && styles.tabActive]}
          onPress={() => setActiveTab('past')}
        >
          <Text style={[styles.tabText, activeTab === 'past' && styles.tabTextActive]}>
            Past
          </Text>
        </TouchableOpacity>
      </View>

      {/* Error Banner */}
      {error && (
        <View style={styles.errorBanner}>
          <Icon name="info" size={16} color="#FF6B35" />
          <Text style={styles.errorText}>{error}</Text>
        </View>
      )}

      {/* Appointments List */}
      <FlatList
        data={filteredAppointments}
        renderItem={renderAppointment}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor="#FF6B35"
            colors={['#FF6B35']}
          />
        }
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Icon name="calendar" size={48} color="#DDD" />
            <Text style={styles.emptyText}>
              {activeTab === 'upcoming' ? 'No upcoming appointments' : 'No past appointments'}
            </Text>
            {activeTab === 'upcoming' && (
              <TouchableOpacity
                style={styles.bookNewButton}
                onPress={() => navigation.navigate('Doctors')}
              >
                <Text style={styles.bookNewButtonText}>Book an Appointment</Text>
              </TouchableOpacity>
            )}
          </View>
        }
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F7FA',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5F7FA',
  },
  loadingText: {
    marginTop: 12,
    fontSize: 16,
    color: '#666',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    paddingTop: Platform.OS === 'ios' ? 60 : 20,
    backgroundColor: '#FFF',
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1A1A1A',
  },
  addButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#FF6B35',
    justifyContent: 'center',
    alignItems: 'center',
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: '#FFF',
    paddingHorizontal: 20,
    paddingBottom: 12,
  },
  tab: {
    paddingVertical: 8,
    paddingHorizontal: 20,
    marginRight: 12,
    borderRadius: 20,
    backgroundColor: '#F5F7FA',
  },
  tabActive: {
    backgroundColor: '#FF6B35',
  },
  tabText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#666',
  },
  tabTextActive: {
    color: '#FFF',
  },
  errorBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFF5F2',
    padding: 12,
    marginHorizontal: 16,
    marginTop: 8,
    borderRadius: 8,
  },
  errorText: {
    fontSize: 12,
    color: '#FF6B35',
    marginLeft: 8,
  },
  listContent: {
    padding: 16,
  },
  appointmentCard: {
    backgroundColor: '#FFF',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  appointmentHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  dateContainer: {},
  dateText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1A1A1A',
  },
  timeText: {
    fontSize: 14,
    color: '#666',
    marginTop: 2,
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  statusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    marginRight: 6,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '500',
    textTransform: 'capitalize',
  },
  doctorInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  avatarSmall: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#FF6B35',
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarSmallText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FFF',
  },
  doctorDetails: {
    flex: 1,
    marginLeft: 12,
  },
  doctorName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1A1A1A',
  },
  doctorSpecialty: {
    fontSize: 12,
    color: '#666',
    marginTop: 2,
  },
  consultationType: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F5F7FA',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  consultationText: {
    fontSize: 10,
    color: '#666',
    marginLeft: 4,
    textTransform: 'capitalize',
  },
  appointmentDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 12,
  },
  reasonText: {
    flex: 1,
    fontSize: 14,
    color: '#666',
  },
  feeText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1A1A1A',
    marginLeft: 12,
  },
  actionButtons: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#F0F0F0',
  },
  joinButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#4CAF50',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 8,
  },
  joinButtonText: {
    color: '#FFF',
    fontSize: 12,
    fontWeight: '600',
    marginLeft: 6,
  },
  rescheduleButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFF5F2',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 8,
  },
  rescheduleButtonText: {
    color: '#FF6B35',
    fontSize: 12,
    fontWeight: '600',
    marginLeft: 6,
  },
  cancelButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#FFEBEE',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 'auto',
  },
  emptyContainer: {
    alignItems: 'center',
    paddingVertical: 48,
  },
  emptyText: {
    fontSize: 16,
    color: '#666',
    marginTop: 16,
  },
  bookNewButton: {
    backgroundColor: '#FF6B35',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 24,
    marginTop: 16,
  },
  bookNewButtonText: {
    color: '#FFF',
    fontSize: 14,
    fontWeight: '600',
  },
});

export default AppointmentsScreen;
