/**
 * Health Dashboard Screen
 * Displays health data from Apple HealthKit (iOS) or Health Connect (Android)
 * 
 * Shows: Steps, Heart Rate, Sleep, Activity metrics
 */

import React, { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  RefreshControl,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  Platform,
  Dimensions,
} from 'react-native';
import Icon from 'react-native-vector-icons/Feather';
import healthService, {
  HealthMetrics,
  HeartRateData,
  SleepData,
  HealthServiceStatus,
} from '../services/HealthService';

const { width } = Dimensions.get('window');

interface HealthDashboardProps {
  navigation?: any;
}

const HealthDashboard: React.FC<HealthDashboardProps> = ({ navigation }) => {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [status, setStatus] = useState<HealthServiceStatus | null>(null);
  const [metrics, setMetrics] = useState<HealthMetrics | null>(null);
  const [heartRate, setHeartRate] = useState<HeartRateData | null>(null);
  const [sleep, setSleep] = useState<SleepData | null>(null);
  const [historicalSteps, setHistoricalSteps] = useState<Array<{ date: string; value: number }>>([]);

  // Initialize health service
  useEffect(() => {
    initializeHealth();
  }, []);

  const initializeHealth = async () => {
    try {
      setLoading(true);
      
      // Check availability
      const serviceStatus = await healthService.getStatus();
      setStatus(serviceStatus);

      if (!serviceStatus.available) {
        Alert.alert(
          'Health Services Unavailable',
          Platform.OS === 'ios'
            ? 'Apple HealthKit is not available on this device.'
            : 'Health Connect is not installed. Please install it from the Play Store.',
          [{ text: 'OK' }]
        );
        setLoading(false);
        return;
      }

      // Initialize and request permissions
      const initialized = await healthService.initialize();
      
      if (initialized) {
        await fetchHealthData();
      } else {
        Alert.alert(
          'Permission Required',
          `Please grant ${serviceStatus.serviceName} permissions to view your health data.`,
          [
            { text: 'Cancel', style: 'cancel' },
            { text: 'Try Again', onPress: initializeHealth },
          ]
        );
      }
    } catch (error) {
      console.error('Health initialization error:', error);
      Alert.alert('Error', 'Failed to initialize health services.');
    } finally {
      setLoading(false);
    }
  };

  const fetchHealthData = async () => {
    try {
      const [activityData, heartRateData, sleepData, stepsHistory] = await Promise.all([
        healthService.getTodayActivity(),
        healthService.getHeartRate(),
        healthService.getSleepAnalysis(),
        healthService.getHistoricalSteps(7),
      ]);

      setMetrics(activityData);
      setHeartRate(heartRateData);
      setSleep(sleepData);
      setHistoricalSteps(stepsHistory);
    } catch (error) {
      console.error('Fetch health data error:', error);
    }
  };

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await fetchHealthData();
    setRefreshing(false);
  }, []);

  const formatNumber = (num: number): string => {
    if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'k';
    }
    return Math.round(num).toString();
  };

  const formatTime = (minutes: number): string => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    if (hours > 0) {
      return `${hours}h ${mins}m`;
    }
    return `${mins}m`;
  };

  // Render loading state
  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#FF6B35" />
        <Text style={styles.loadingText}>
          Connecting to {Platform.OS === 'ios' ? 'Apple Health' : 'Health Connect'}...
        </Text>
      </View>
    );
  }

  // Render permission required state
  if (!status?.initialized || !status?.permissionsGranted) {
    return (
      <View style={styles.permissionContainer}>
        <Icon name="shield" size={64} color="#FF6B35" />
        <Text style={styles.permissionTitle}>Health Access Required</Text>
        <Text style={styles.permissionText}>
          Grant access to {status?.serviceName || 'health services'} to see your health metrics.
        </Text>
        <TouchableOpacity style={styles.permissionButton} onPress={initializeHealth}>
          <Text style={styles.permissionButtonText}>Enable Health Access</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <ScrollView
      style={styles.container}
      refreshControl={
        <RefreshControl
          refreshing={refreshing}
          onRefresh={onRefresh}
          tintColor="#FF6B35"
          colors={['#FF6B35']}
        />
      }
    >
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Health Dashboard</Text>
        <Text style={styles.headerSubtitle}>
          {Platform.OS === 'ios' ? '🍎 Apple Health' : '🤖 Health Connect'}
        </Text>
      </View>

      {/* Activity Metrics */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Today's Activity</Text>
        <View style={styles.metricsGrid}>
          {/* Steps */}
          <View style={[styles.metricCard, styles.stepsCard]}>
            <View style={styles.metricIcon}>
              <Icon name="activity" size={24} color="#4CAF50" />
            </View>
            <Text style={styles.metricValue}>{formatNumber(metrics?.steps || 0)}</Text>
            <Text style={styles.metricLabel}>Steps</Text>
            <View style={styles.progressBar}>
              <View
                style={[
                  styles.progressFill,
                  { width: `${Math.min(100, ((metrics?.steps || 0) / 10000) * 100)}%` },
                  { backgroundColor: '#4CAF50' },
                ]}
              />
            </View>
            <Text style={styles.metricGoal}>Goal: 10,000</Text>
          </View>

          {/* Distance */}
          <View style={[styles.metricCard, styles.distanceCard]}>
            <View style={styles.metricIcon}>
              <Icon name="map-pin" size={24} color="#2196F3" />
            </View>
            <Text style={styles.metricValue}>
              {((metrics?.distance || 0) / 1000).toFixed(1)} km
            </Text>
            <Text style={styles.metricLabel}>Distance</Text>
          </View>

          {/* Calories */}
          <View style={[styles.metricCard, styles.caloriesCard]}>
            <View style={styles.metricIcon}>
              <Icon name="zap" size={24} color="#FF9800" />
            </View>
            <Text style={styles.metricValue}>{formatNumber(metrics?.activeCalories || 0)}</Text>
            <Text style={styles.metricLabel}>Active Cal</Text>
          </View>

          {/* Flights Climbed */}
          <View style={[styles.metricCard, styles.flightsCard]}>
            <View style={styles.metricIcon}>
              <Icon name="trending-up" size={24} color="#9C27B0" />
            </View>
            <Text style={styles.metricValue}>{metrics?.flightsClimbed || 0}</Text>
            <Text style={styles.metricLabel}>Floors</Text>
          </View>
        </View>
      </View>

      {/* Heart Rate */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Heart Rate</Text>
        <View style={styles.heartRateCard}>
          <View style={styles.heartRateMain}>
            <Icon name="heart" size={32} color="#E91E63" />
            <View style={styles.heartRateValue}>
              <Text style={styles.heartRateBPM}>
                {heartRate?.current || '--'}
              </Text>
              <Text style={styles.heartRateUnit}>BPM</Text>
            </View>
          </View>
          <View style={styles.heartRateStats}>
            <View style={styles.heartRateStat}>
              <Text style={styles.heartRateStatValue}>{heartRate?.resting || '--'}</Text>
              <Text style={styles.heartRateStatLabel}>Resting</Text>
            </View>
            <View style={styles.heartRateStat}>
              <Text style={styles.heartRateStatValue}>{heartRate?.average || '--'}</Text>
              <Text style={styles.heartRateStatLabel}>Average</Text>
            </View>
            <View style={styles.heartRateStat}>
              <Text style={styles.heartRateStatValue}>{heartRate?.max || '--'}</Text>
              <Text style={styles.heartRateStatLabel}>Max</Text>
            </View>
          </View>
        </View>
      </View>

      {/* Sleep */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Sleep Analysis</Text>
        <View style={styles.sleepCard}>
          <View style={styles.sleepHeader}>
            <Icon name="moon" size={28} color="#673AB7" />
            <View style={styles.sleepMain}>
              <Text style={styles.sleepDuration}>
                {formatTime(sleep?.totalMinutes || 0)}
              </Text>
              <Text style={styles.sleepLabel}>Total Sleep</Text>
            </View>
            <View style={styles.sleepScore}>
              <Text style={styles.sleepScoreValue}>{sleep?.sleepScore || 0}</Text>
              <Text style={styles.sleepScoreLabel}>Score</Text>
            </View>
          </View>
          <View style={styles.sleepBreakdown}>
            <View style={styles.sleepStage}>
              <View style={[styles.sleepDot, { backgroundColor: '#9575CD' }]} />
              <Text style={styles.sleepStageName}>Light</Text>
              <Text style={styles.sleepStageTime}>{formatTime(sleep?.lightMinutes || 0)}</Text>
            </View>
            <View style={styles.sleepStage}>
              <View style={[styles.sleepDot, { backgroundColor: '#5E35B1' }]} />
              <Text style={styles.sleepStageName}>Deep</Text>
              <Text style={styles.sleepStageTime}>{formatTime(sleep?.deepMinutes || 0)}</Text>
            </View>
            <View style={styles.sleepStage}>
              <View style={[styles.sleepDot, { backgroundColor: '#7E57C2' }]} />
              <Text style={styles.sleepStageName}>REM</Text>
              <Text style={styles.sleepStageTime}>{formatTime(sleep?.remMinutes || 0)}</Text>
            </View>
            <View style={styles.sleepStage}>
              <View style={[styles.sleepDot, { backgroundColor: '#EF5350' }]} />
              <Text style={styles.sleepStageName}>Awake</Text>
              <Text style={styles.sleepStageTime}>{formatTime(sleep?.awakeMinutes || 0)}</Text>
            </View>
          </View>
        </View>
      </View>

      {/* Weekly Steps Chart */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Weekly Steps</Text>
        <View style={styles.chartCard}>
          <View style={styles.chartBars}>
            {historicalSteps.map((day, index) => {
              const maxSteps = Math.max(...historicalSteps.map(d => d.value), 10000);
              const height = (day.value / maxSteps) * 120;
              const isToday = index === historicalSteps.length - 1;
              
              return (
                <View key={day.date} style={styles.chartBarContainer}>
                  <Text style={styles.chartBarValue}>
                    {day.value >= 1000 ? `${(day.value / 1000).toFixed(0)}k` : day.value}
                  </Text>
                  <View
                    style={[
                      styles.chartBar,
                      { height: Math.max(height, 4) },
                      isToday && styles.chartBarToday,
                    ]}
                  />
                  <Text style={styles.chartBarLabel}>
                    {new Date(day.date).toLocaleDateString('en-US', { weekday: 'short' })}
                  </Text>
                </View>
              );
            })}
          </View>
        </View>
      </View>

      {/* Sync Info */}
      <View style={styles.syncInfo}>
        <Icon name="refresh-cw" size={14} color="#999" />
        <Text style={styles.syncText}>
          Data from {status?.serviceName} • Pull to refresh
        </Text>
      </View>

      <View style={{ height: 40 }} />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F7FA',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5F7FA',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#666',
  },
  permissionContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 32,
    backgroundColor: '#F5F7FA',
  },
  permissionTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginTop: 24,
    marginBottom: 12,
  },
  permissionText: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginBottom: 32,
    lineHeight: 24,
  },
  permissionButton: {
    backgroundColor: '#FF6B35',
    paddingHorizontal: 32,
    paddingVertical: 16,
    borderRadius: 12,
  },
  permissionButtonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '600',
  },
  header: {
    padding: 20,
    paddingTop: Platform.OS === 'ios' ? 60 : 20,
    backgroundColor: '#FFF',
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1A1A1A',
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  section: {
    padding: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
    marginBottom: 12,
  },
  metricsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  metricCard: {
    width: (width - 48) / 2,
    backgroundColor: '#FFF',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  stepsCard: {},
  distanceCard: {},
  caloriesCard: {},
  flightsCard: {},
  metricIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#F5F7FA',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  metricValue: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1A1A1A',
  },
  metricLabel: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  progressBar: {
    height: 6,
    backgroundColor: '#E8E8E8',
    borderRadius: 3,
    marginTop: 12,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 3,
  },
  metricGoal: {
    fontSize: 11,
    color: '#999',
    marginTop: 6,
  },
  heartRateCard: {
    backgroundColor: '#FFF',
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  heartRateMain: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  heartRateValue: {
    marginLeft: 16,
  },
  heartRateBPM: {
    fontSize: 48,
    fontWeight: 'bold',
    color: '#E91E63',
  },
  heartRateUnit: {
    fontSize: 14,
    color: '#666',
  },
  heartRateStats: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    borderTopWidth: 1,
    borderTopColor: '#F0F0F0',
    paddingTop: 16,
  },
  heartRateStat: {
    alignItems: 'center',
  },
  heartRateStatValue: {
    fontSize: 20,
    fontWeight: '600',
    color: '#333',
  },
  heartRateStatLabel: {
    fontSize: 12,
    color: '#999',
    marginTop: 4,
  },
  sleepCard: {
    backgroundColor: '#FFF',
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  sleepHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  sleepMain: {
    flex: 1,
    marginLeft: 16,
  },
  sleepDuration: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#673AB7',
  },
  sleepLabel: {
    fontSize: 14,
    color: '#666',
  },
  sleepScore: {
    alignItems: 'center',
    backgroundColor: '#EDE7F6',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 12,
  },
  sleepScoreValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#673AB7',
  },
  sleepScoreLabel: {
    fontSize: 11,
    color: '#7E57C2',
  },
  sleepBreakdown: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderTopWidth: 1,
    borderTopColor: '#F0F0F0',
    paddingTop: 16,
  },
  sleepStage: {
    alignItems: 'center',
  },
  sleepDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginBottom: 4,
  },
  sleepStageName: {
    fontSize: 12,
    color: '#666',
  },
  sleepStageTime: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
    marginTop: 2,
  },
  chartCard: {
    backgroundColor: '#FFF',
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  chartBars: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    height: 160,
  },
  chartBarContainer: {
    alignItems: 'center',
    flex: 1,
  },
  chartBarValue: {
    fontSize: 10,
    color: '#999',
    marginBottom: 4,
  },
  chartBar: {
    width: 24,
    backgroundColor: '#4CAF50',
    borderRadius: 4,
  },
  chartBarToday: {
    backgroundColor: '#FF6B35',
  },
  chartBarLabel: {
    fontSize: 11,
    color: '#666',
    marginTop: 8,
  },
  syncInfo: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    gap: 8,
  },
  syncText: {
    fontSize: 12,
    color: '#999',
  },
});

export default HealthDashboard;
