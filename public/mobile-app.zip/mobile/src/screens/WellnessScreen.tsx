/**
 * Wellness Screen
 * AI-powered wellness plans - Diet, Workout, Yoga
 * Connected to backend AI wellness API
 */

import React, { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  Platform,
  TextInput,
  Alert,
} from 'react-native';
import Icon from 'react-native-vector-icons/Feather';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { API_BASE_URL } from '../utils/config';

interface WellnessPlan {
  diet: {
    breakfast: string[];
    lunch: string[];
    dinner: string[];
    snacks: string[];
    dailyCalories: number;
    macros: { carbs: number; protein: number; fats: number };
  };
  workout: {
    exercises: Array<{
      name: string;
      duration: string;
      sets?: number;
      reps?: number;
    }>;
    totalDuration: string;
    caloriesBurn: number;
  };
  yoga: {
    poses: Array<{
      name: string;
      duration: string;
      benefits: string;
    }>;
    totalDuration: string;
  };
  tips: string[];
}

interface UserProfile {
  age: number;
  gender: string;
  weight: number;
  height: number;
  activityLevel: string;
  focusAreas: string[];
  medicalConditions: string[];
}

interface WellnessScreenProps {
  navigation: any;
}

const FOCUS_AREAS = [
  { id: 'weight_loss', label: 'Weight Loss', icon: 'trending-down' },
  { id: 'muscle_gain', label: 'Muscle Gain', icon: 'trending-up' },
  { id: 'stress', label: 'Stress Relief', icon: 'sun' },
  { id: 'sleep', label: 'Better Sleep', icon: 'moon' },
  { id: 'energy', label: 'More Energy', icon: 'zap' },
  { id: 'flexibility', label: 'Flexibility', icon: 'maximize-2' },
  { id: 'diabetes', label: 'Diabetes Care', icon: 'heart' },
  { id: 'hypertension', label: 'Heart Health', icon: 'activity' },
];

const ACTIVITY_LEVELS = [
  { id: 'sedentary', label: 'Sedentary', desc: 'Little or no exercise' },
  { id: 'light', label: 'Light', desc: '1-3 days/week' },
  { id: 'moderate', label: 'Moderate', desc: '3-5 days/week' },
  { id: 'active', label: 'Active', desc: '6-7 days/week' },
  { id: 'very_active', label: 'Very Active', desc: 'Athlete level' },
];

const WellnessScreen: React.FC<WellnessScreenProps> = ({ navigation }) => {
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [showSetup, setShowSetup] = useState(true);
  const [plan, setPlan] = useState<WellnessPlan | null>(null);
  const [activeTab, setActiveTab] = useState<'diet' | 'workout' | 'yoga'>('diet');
  
  const [profile, setProfile] = useState<UserProfile>({
    age: 30,
    gender: 'male',
    weight: 70,
    height: 170,
    activityLevel: 'moderate',
    focusAreas: [],
    medicalConditions: [],
  });

  useEffect(() => {
    loadCachedPlan();
  }, []);

  const loadCachedPlan = async () => {
    try {
      const cached = await AsyncStorage.getItem('cached_wellness_plan');
      if (cached) {
        setPlan(JSON.parse(cached));
        setShowSetup(false);
      }
    } catch (err) {
      console.error('Load cached plan error:', err);
    }
  };

  const generatePlan = async () => {
    if (profile.focusAreas.length === 0) {
      Alert.alert('Select Focus Areas', 'Please select at least one focus area');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`${API_BASE_URL}/api/ai-wellness/generate-plan`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          age: profile.age,
          gender: profile.gender,
          weight: profile.weight,
          height: profile.height,
          activity_level: profile.activityLevel,
          focus_areas: profile.focusAreas,
          medical_conditions: profile.medicalConditions,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to generate plan');
      }

      const data = await response.json();
      
      // Transform API response to our format
      const newPlan: WellnessPlan = {
        diet: {
          breakfast: data.diet?.breakfast || ['Oatmeal with fruits', 'Green tea'],
          lunch: data.diet?.lunch || ['Grilled chicken salad', 'Brown rice'],
          dinner: data.diet?.dinner || ['Steamed vegetables', 'Dal'],
          snacks: data.diet?.snacks || ['Nuts', 'Fresh fruits'],
          dailyCalories: data.diet?.daily_calories || 2000,
          macros: data.diet?.macros || { carbs: 50, protein: 25, fats: 25 },
        },
        workout: {
          exercises: data.workout?.exercises || [
            { name: 'Warm-up Walk', duration: '10 min' },
            { name: 'Push-ups', duration: '5 min', sets: 3, reps: 15 },
            { name: 'Squats', duration: '5 min', sets: 3, reps: 20 },
            { name: 'Plank', duration: '3 min', sets: 3 },
            { name: 'Cool-down Stretch', duration: '7 min' },
          ],
          totalDuration: data.workout?.total_duration || '30 min',
          caloriesBurn: data.workout?.calories_burn || 300,
        },
        yoga: {
          poses: data.yoga?.poses || [
            { name: 'Surya Namaskar', duration: '10 min', benefits: 'Full body stretch' },
            { name: 'Trikonasana', duration: '5 min', benefits: 'Side stretch' },
            { name: 'Bhujangasana', duration: '5 min', benefits: 'Back strength' },
            { name: 'Shavasana', duration: '10 min', benefits: 'Relaxation' },
          ],
          totalDuration: data.yoga?.total_duration || '30 min',
        },
        tips: data.tips || [
          'Drink at least 8 glasses of water daily',
          'Get 7-8 hours of quality sleep',
          'Take short breaks during work',
          'Practice mindfulness for 10 minutes daily',
        ],
      };

      setPlan(newPlan);
      setShowSetup(false);
      
      // Cache the plan
      await AsyncStorage.setItem('cached_wellness_plan', JSON.stringify(newPlan));
    } catch (err) {
      console.error('Generate plan error:', err);
      Alert.alert('Error', 'Failed to generate wellness plan. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await generatePlan();
    setRefreshing(false);
  }, [profile]);

  const toggleFocusArea = (id: string) => {
    setProfile((prev) => ({
      ...prev,
      focusAreas: prev.focusAreas.includes(id)
        ? prev.focusAreas.filter((a) => a !== id)
        : [...prev.focusAreas, id],
    }));
  };

  const renderSetup = () => (
    <ScrollView style={styles.setupContainer} showsVerticalScrollIndicator={false}>
      <Text style={styles.setupTitle}>Create Your Wellness Plan</Text>
      <Text style={styles.setupSubtitle}>
        Tell us about yourself to get a personalized plan
      </Text>

      {/* Basic Info */}
      <View style={styles.formSection}>
        <Text style={styles.formLabel}>Basic Information</Text>
        <View style={styles.formRow}>
          <View style={styles.formField}>
            <Text style={styles.fieldLabel}>Age</Text>
            <TextInput
              style={styles.input}
              value={String(profile.age)}
              onChangeText={(v) => setProfile({ ...profile, age: parseInt(v) || 0 })}
              keyboardType="number-pad"
            />
          </View>
          <View style={styles.formField}>
            <Text style={styles.fieldLabel}>Weight (kg)</Text>
            <TextInput
              style={styles.input}
              value={String(profile.weight)}
              onChangeText={(v) => setProfile({ ...profile, weight: parseInt(v) || 0 })}
              keyboardType="number-pad"
            />
          </View>
          <View style={styles.formField}>
            <Text style={styles.fieldLabel}>Height (cm)</Text>
            <TextInput
              style={styles.input}
              value={String(profile.height)}
              onChangeText={(v) => setProfile({ ...profile, height: parseInt(v) || 0 })}
              keyboardType="number-pad"
            />
          </View>
        </View>

        <Text style={styles.fieldLabel}>Gender</Text>
        <View style={styles.genderRow}>
          {['male', 'female', 'other'].map((g) => (
            <TouchableOpacity
              key={g}
              style={[styles.genderButton, profile.gender === g && styles.genderButtonActive]}
              onPress={() => setProfile({ ...profile, gender: g })}
            >
              <Text style={[styles.genderText, profile.gender === g && styles.genderTextActive]}>
                {g.charAt(0).toUpperCase() + g.slice(1)}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Activity Level */}
      <View style={styles.formSection}>
        <Text style={styles.formLabel}>Activity Level</Text>
        {ACTIVITY_LEVELS.map((level) => (
          <TouchableOpacity
            key={level.id}
            style={[
              styles.activityOption,
              profile.activityLevel === level.id && styles.activityOptionActive,
            ]}
            onPress={() => setProfile({ ...profile, activityLevel: level.id })}
          >
            <View>
              <Text
                style={[
                  styles.activityLabel,
                  profile.activityLevel === level.id && styles.activityLabelActive,
                ]}
              >
                {level.label}
              </Text>
              <Text style={styles.activityDesc}>{level.desc}</Text>
            </View>
            {profile.activityLevel === level.id && (
              <Icon name="check" size={20} color="#FF6B35" />
            )}
          </TouchableOpacity>
        ))}
      </View>

      {/* Focus Areas */}
      <View style={styles.formSection}>
        <Text style={styles.formLabel}>Focus Areas</Text>
        <Text style={styles.formHint}>Select one or more goals</Text>
        <View style={styles.focusGrid}>
          {FOCUS_AREAS.map((area) => (
            <TouchableOpacity
              key={area.id}
              style={[
                styles.focusChip,
                profile.focusAreas.includes(area.id) && styles.focusChipActive,
              ]}
              onPress={() => toggleFocusArea(area.id)}
            >
              <Icon
                name={area.icon}
                size={16}
                color={profile.focusAreas.includes(area.id) ? '#FFF' : '#666'}
              />
              <Text
                style={[
                  styles.focusChipText,
                  profile.focusAreas.includes(area.id) && styles.focusChipTextActive,
                ]}
              >
                {area.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Generate Button */}
      <TouchableOpacity
        style={[styles.generateButton, loading && styles.generateButtonDisabled]}
        onPress={generatePlan}
        disabled={loading}
      >
        {loading ? (
          <ActivityIndicator color="#FFF" />
        ) : (
          <>
            <Icon name="zap" size={20} color="#FFF" />
            <Text style={styles.generateButtonText}>Generate My Plan</Text>
          </>
        )}
      </TouchableOpacity>

      <View style={{ height: 40 }} />
    </ScrollView>
  );

  const renderPlan = () => (
    <ScrollView
      style={styles.planContainer}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#FF6B35" />
      }
    >
      {/* Tabs */}
      <View style={styles.tabContainer}>
        {(['diet', 'workout', 'yoga'] as const).map((tab) => (
          <TouchableOpacity
            key={tab}
            style={[styles.tab, activeTab === tab && styles.tabActive]}
            onPress={() => setActiveTab(tab)}
          >
            <Icon
              name={tab === 'diet' ? 'coffee' : tab === 'workout' ? 'activity' : 'sun'}
              size={18}
              color={activeTab === tab ? '#FF6B35' : '#999'}
            />
            <Text style={[styles.tabText, activeTab === tab && styles.tabTextActive]}>
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Diet Tab */}
      {activeTab === 'diet' && plan && (
        <View style={styles.tabContent}>
          <View style={styles.calorieCard}>
            <Text style={styles.calorieValue}>{plan.diet.dailyCalories}</Text>
            <Text style={styles.calorieLabel}>Daily Calories</Text>
            <View style={styles.macrosRow}>
              <View style={styles.macroItem}>
                <Text style={styles.macroValue}>{plan.diet.macros.carbs}%</Text>
                <Text style={styles.macroLabel}>Carbs</Text>
              </View>
              <View style={styles.macroItem}>
                <Text style={styles.macroValue}>{plan.diet.macros.protein}%</Text>
                <Text style={styles.macroLabel}>Protein</Text>
              </View>
              <View style={styles.macroItem}>
                <Text style={styles.macroValue}>{plan.diet.macros.fats}%</Text>
                <Text style={styles.macroLabel}>Fats</Text>
              </View>
            </View>
          </View>

          {[
            { title: '🌅 Breakfast', items: plan.diet.breakfast },
            { title: '☀️ Lunch', items: plan.diet.lunch },
            { title: '🌙 Dinner', items: plan.diet.dinner },
            { title: '🍎 Snacks', items: plan.diet.snacks },
          ].map((meal) => (
            <View key={meal.title} style={styles.mealCard}>
              <Text style={styles.mealTitle}>{meal.title}</Text>
              {meal.items.map((item, idx) => (
                <View key={idx} style={styles.mealItem}>
                  <Icon name="check-circle" size={16} color="#4CAF50" />
                  <Text style={styles.mealItemText}>{item}</Text>
                </View>
              ))}
            </View>
          ))}
        </View>
      )}

      {/* Workout Tab */}
      {activeTab === 'workout' && plan && (
        <View style={styles.tabContent}>
          <View style={styles.workoutSummary}>
            <View style={styles.summaryItem}>
              <Icon name="clock" size={24} color="#FF6B35" />
              <Text style={styles.summaryValue}>{plan.workout.totalDuration}</Text>
              <Text style={styles.summaryLabel}>Duration</Text>
            </View>
            <View style={styles.summaryItem}>
              <Icon name="zap" size={24} color="#FF6B35" />
              <Text style={styles.summaryValue}>{plan.workout.caloriesBurn}</Text>
              <Text style={styles.summaryLabel}>Calories Burn</Text>
            </View>
          </View>

          {plan.workout.exercises.map((exercise, idx) => (
            <View key={idx} style={styles.exerciseCard}>
              <View style={styles.exerciseNumber}>
                <Text style={styles.exerciseNumberText}>{idx + 1}</Text>
              </View>
              <View style={styles.exerciseInfo}>
                <Text style={styles.exerciseName}>{exercise.name}</Text>
                <Text style={styles.exerciseDetails}>
                  {exercise.duration}
                  {exercise.sets && exercise.reps && ` • ${exercise.sets}x${exercise.reps}`}
                </Text>
              </View>
            </View>
          ))}
        </View>
      )}

      {/* Yoga Tab */}
      {activeTab === 'yoga' && plan && (
        <View style={styles.tabContent}>
          <View style={styles.yogaHeader}>
            <Icon name="sun" size={32} color="#9C27B0" />
            <Text style={styles.yogaDuration}>{plan.yoga.totalDuration}</Text>
            <Text style={styles.yogaLabel}>Today's Yoga Session</Text>
          </View>

          {plan.yoga.poses.map((pose, idx) => (
            <View key={idx} style={styles.poseCard}>
              <Text style={styles.poseName}>{pose.name}</Text>
              <Text style={styles.poseDuration}>{pose.duration}</Text>
              <Text style={styles.poseBenefits}>{pose.benefits}</Text>
            </View>
          ))}
        </View>
      )}

      {/* Tips */}
      {plan && (
        <View style={styles.tipsSection}>
          <Text style={styles.tipsTitle}>💡 Daily Tips</Text>
          {plan.tips.map((tip, idx) => (
            <View key={idx} style={styles.tipItem}>
              <Icon name="check" size={14} color="#4CAF50" />
              <Text style={styles.tipText}>{tip}</Text>
            </View>
          ))}
        </View>
      )}

      {/* Regenerate Button */}
      <TouchableOpacity style={styles.regenerateButton} onPress={() => setShowSetup(true)}>
        <Icon name="refresh-cw" size={16} color="#FF6B35" />
        <Text style={styles.regenerateText}>Update My Profile</Text>
      </TouchableOpacity>

      <View style={{ height: 40 }} />
    </ScrollView>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>AI Wellness</Text>
        <Text style={styles.headerSubtitle}>Personalized health plans powered by AI</Text>
      </View>

      {showSetup ? renderSetup() : renderPlan()}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F7FA',
  },
  header: {
    padding: 20,
    paddingTop: Platform.OS === 'ios' ? 60 : 20,
    backgroundColor: '#FFF',
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1A1A1A',
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  setupContainer: {
    flex: 1,
    padding: 16,
  },
  setupTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1A1A1A',
    marginBottom: 8,
  },
  setupSubtitle: {
    fontSize: 14,
    color: '#666',
    marginBottom: 24,
  },
  formSection: {
    backgroundColor: '#FFF',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
  },
  formLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1A1A1A',
    marginBottom: 12,
  },
  formHint: {
    fontSize: 12,
    color: '#999',
    marginBottom: 12,
  },
  formRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  formField: {
    flex: 1,
    marginHorizontal: 4,
  },
  fieldLabel: {
    fontSize: 12,
    color: '#666',
    marginBottom: 6,
  },
  input: {
    backgroundColor: '#F5F7FA',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    color: '#333',
  },
  genderRow: {
    flexDirection: 'row',
    marginTop: 8,
  },
  genderButton: {
    flex: 1,
    paddingVertical: 12,
    backgroundColor: '#F5F7FA',
    borderRadius: 8,
    alignItems: 'center',
    marginHorizontal: 4,
  },
  genderButtonActive: {
    backgroundColor: '#FF6B35',
  },
  genderText: {
    fontSize: 14,
    color: '#666',
  },
  genderTextActive: {
    color: '#FFF',
    fontWeight: '600',
  },
  activityOption: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 12,
    backgroundColor: '#F5F7FA',
    borderRadius: 8,
    marginBottom: 8,
  },
  activityOptionActive: {
    backgroundColor: '#FFF5F2',
    borderWidth: 1,
    borderColor: '#FF6B35',
  },
  activityLabel: {
    fontSize: 14,
    fontWeight: '500',
    color: '#333',
  },
  activityLabelActive: {
    color: '#FF6B35',
  },
  activityDesc: {
    fontSize: 12,
    color: '#999',
    marginTop: 2,
  },
  focusGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  focusChip: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F5F7FA',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 8,
    marginBottom: 8,
  },
  focusChipActive: {
    backgroundColor: '#FF6B35',
  },
  focusChipText: {
    fontSize: 12,
    color: '#666',
    marginLeft: 6,
  },
  focusChipTextActive: {
    color: '#FFF',
  },
  generateButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FF6B35',
    paddingVertical: 16,
    borderRadius: 12,
    marginTop: 16,
  },
  generateButtonDisabled: {
    opacity: 0.7,
  },
  generateButtonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 8,
  },
  planContainer: {
    flex: 1,
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: '#FFF',
    padding: 8,
    marginHorizontal: 16,
    marginTop: 16,
    borderRadius: 12,
  },
  tab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderRadius: 8,
  },
  tabActive: {
    backgroundColor: '#FFF5F2',
  },
  tabText: {
    fontSize: 14,
    color: '#999',
    marginLeft: 6,
  },
  tabTextActive: {
    color: '#FF6B35',
    fontWeight: '600',
  },
  tabContent: {
    padding: 16,
  },
  calorieCard: {
    backgroundColor: '#FF6B35',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    marginBottom: 16,
  },
  calorieValue: {
    fontSize: 48,
    fontWeight: 'bold',
    color: '#FFF',
  },
  calorieLabel: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.8)',
  },
  macrosRow: {
    flexDirection: 'row',
    marginTop: 16,
  },
  macroItem: {
    flex: 1,
    alignItems: 'center',
  },
  macroValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFF',
  },
  macroLabel: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.8)',
  },
  mealCard: {
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
  },
  mealTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1A1A1A',
    marginBottom: 12,
  },
  mealItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  mealItemText: {
    fontSize: 14,
    color: '#666',
    marginLeft: 8,
  },
  workoutSummary: {
    flexDirection: 'row',
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 20,
    marginBottom: 16,
  },
  summaryItem: {
    flex: 1,
    alignItems: 'center',
  },
  summaryValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1A1A1A',
    marginTop: 8,
  },
  summaryLabel: {
    fontSize: 12,
    color: '#666',
  },
  exerciseCard: {
    flexDirection: 'row',
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 8,
    alignItems: 'center',
  },
  exerciseNumber: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#FF6B35',
    justifyContent: 'center',
    alignItems: 'center',
  },
  exerciseNumberText: {
    color: '#FFF',
    fontWeight: 'bold',
  },
  exerciseInfo: {
    marginLeft: 12,
  },
  exerciseName: {
    fontSize: 16,
    fontWeight: '500',
    color: '#1A1A1A',
  },
  exerciseDetails: {
    fontSize: 12,
    color: '#666',
    marginTop: 2,
  },
  yogaHeader: {
    alignItems: 'center',
    backgroundColor: '#F3E5F5',
    borderRadius: 16,
    padding: 24,
    marginBottom: 16,
  },
  yogaDuration: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#9C27B0',
    marginTop: 8,
  },
  yogaLabel: {
    fontSize: 14,
    color: '#666',
  },
  poseCard: {
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 8,
  },
  poseName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1A1A1A',
  },
  poseDuration: {
    fontSize: 12,
    color: '#9C27B0',
    marginTop: 4,
  },
  poseBenefits: {
    fontSize: 12,
    color: '#666',
    marginTop: 4,
  },
  tipsSection: {
    backgroundColor: '#FFF',
    borderRadius: 16,
    padding: 16,
    margin: 16,
  },
  tipsTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1A1A1A',
    marginBottom: 12,
  },
  tipItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  tipText: {
    fontSize: 14,
    color: '#666',
    marginLeft: 8,
    flex: 1,
  },
  regenerateButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFF5F2',
    paddingVertical: 12,
    borderRadius: 8,
    marginHorizontal: 16,
  },
  regenerateText: {
    color: '#FF6B35',
    fontSize: 14,
    fontWeight: '500',
    marginLeft: 8,
  },
});

export default WellnessScreen;
