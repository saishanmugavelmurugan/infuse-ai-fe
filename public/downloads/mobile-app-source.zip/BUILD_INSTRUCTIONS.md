# Infuse AI Mobile App - Build Instructions

## Overview
The mobile app is configured using Capacitor and ready for Android APK generation.

## Prerequisites
Before building the APK, ensure you have:
1. **Java JDK 17** or higher installed
2. **Android Studio** with Android SDK installed
3. **Node.js 18+** and **Yarn** installed

## Build Steps

### Option 1: Build via Android Studio (Recommended)
1. Open Android Studio
2. Select "Open an existing project"
3. Navigate to `/app/mobile-app/android`
4. Wait for Gradle sync to complete
5. Build > Build Bundle(s) / APK(s) > Build APK(s)
6. APK will be generated at: `android/app/build/outputs/apk/debug/app-debug.apk`

### Option 2: Build via Command Line
```bash
# Navigate to mobile app directory
cd /app/mobile-app

# Build the frontend (if not already built)
cd ../frontend && yarn build && cd ../mobile-app

# Sync with Capacitor
npx cap sync

# Build the debug APK
cd android && ./gradlew assembleDebug

# For release APK (requires signing key)
./gradlew assembleRelease
```

### Option 3: Build on Your Local Machine
1. Download this project
2. Install dependencies:
   ```bash
   cd frontend && yarn install
   cd ../mobile-app && yarn install
   ```
3. Build frontend and sync:
   ```bash
   cd ../frontend && yarn build
   cd ../mobile-app && npx cap sync
   ```
4. Open in Android Studio:
   ```bash
   npx cap open android
   ```

## APK Location
After successful build:
- Debug APK: `mobile-app/android/app/build/outputs/apk/debug/app-debug.apk`
- Release APK: `mobile-app/android/app/build/outputs/apk/release/app-release.apk`

## App Configuration
- **App ID**: com.infuse.ai
- **App Name**: Infuse AI
- **Min SDK**: 23 (Android 6.0)
- **Target SDK**: 34 (Android 14)

## Features Included
- HealthTrack Pro - Healthcare Management
- SecureSphere - Security Platform
- Push Notifications
- Local Notifications
- Splash Screen
- Status Bar customization

## Notes
- The app loads the web interface from the deployed server
- For offline capability, consider implementing Service Workers
- For production release, configure signing keys in `android/app/build.gradle`

## Troubleshooting
- If Gradle sync fails, try: `./gradlew --refresh-dependencies`
- For SDK issues, ensure ANDROID_HOME is set correctly
- Clear cache: `./gradlew clean`
