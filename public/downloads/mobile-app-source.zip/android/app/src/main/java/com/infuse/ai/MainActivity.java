package com.infuse.ai;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
