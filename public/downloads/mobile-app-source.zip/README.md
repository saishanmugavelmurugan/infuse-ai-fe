# Infuse AI Mobile App

Native mobile application for Infuse AI platform using Capacitor.

## Prerequisites

- Node.js 18+
- Android Studio (for Android builds)
- Xcode (for iOS builds, macOS only)
- Java JDK 11+

## Setup

1. Install dependencies:
```bash
npm install
```

2. Build the web app:
```bash
npm run build
```

3. Sync with native projects:
```bash
npm run sync
```

## Android

### Development

1. Open in Android Studio:
```bash
npm run android
```

2. Or run directly:
```bash
npm run run:android
```

### Build APK

**Debug APK** (for testing):
```bash
npm run build:android
```

The APK will be at: `android/app/build/outputs/apk/debug/app-debug.apk`

**Release APK** (for distribution):
```bash
npm run build:android:release
```

The APK will be at: `android/app/build/outputs/apk/release/app-release.apk`

## iOS

### Development

1. Open in Xcode:
```bash
npm run ios
```

2. Or run directly:
```bash
npm run run:ios
```

### Build IPA

1. Open in Xcode
2. Select your device/simulator
3. Product > Archive
4. Distribute App > Ad Hoc or App Store

## Features

- 🎯 Native performance
- 🔔 Push notifications
- 📱 Full-screen experience
- 🔒 Biometric authentication ready
- 🌐 Offline support
- 🎨 Native splash screen
- 📤 Share functionality

## App Signing

### Android

1. Generate keystore:
```bash
keytool -genkey -v -keystore infuse-ai.keystore -alias infuse-ai -keyalg RSA -keysize 2048 -validity 10000
```

2. Add to `android/app/build.gradle`:
```gradle
signingConfigs {
    release {
        storeFile file('infuse-ai.keystore')
        storePassword 'YOUR_STORE_PASSWORD'
        keyAlias 'infuse-ai'
        keyPassword 'YOUR_KEY_PASSWORD'
    }
}
```

### iOS

1. Get Apple Developer certificate
2. Create provisioning profile
3. Configure in Xcode

## Testing on Device

### Android
1. Enable Developer Options on device
2. Enable USB Debugging
3. Connect device via USB
4. Run `npm run run:android`

### iOS
1. Connect device via USB
2. Trust the computer on device
3. Select device in Xcode
4. Run the app

## Download Links

After building, share the APK file directly for Android testing.
For iOS, use TestFlight for distribution.
